document.addEventListener('DOMContentLoaded', function() {
    const enableToggle = document.getElementById('enableToggle');
    const showTutorialButton = document.getElementById('showTutorial');
    const status = document.getElementById('status');

    // Get initial state
    chrome.storage.local.get(['likemeEnabled'], function(result) {
        enableToggle.checked = result.likemeEnabled !== false;
    });

    // Handle toggle changes
    enableToggle.addEventListener('change', function() {
        const isEnabled = enableToggle.checked;
        
        // Save state
        chrome.storage.local.set({ likemeEnabled: isEnabled });

        // Send message to content script
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: isEnabled ? 'enable' : 'disable'
                });
            }
        });
    });

    // Show tutorial
    showTutorialButton.addEventListener('click', function() {
        chrome.tabs.create({
            url: chrome.runtime.getURL('index.html')
        });
    });

    // Update stats periodically (in a real app, this would fetch from an API)
    function updateStats() {
        const lockedValue = document.querySelector('.stat-card:first-child .stat-value');
        const tipsValue = document.querySelector('.stat-card:last-child .stat-value');
        
        // Simulate random changes
        const currentLocked = parseInt(lockedValue.textContent.replace('$', '').replace(',', ''));
        const currentTips = parseInt(tipsValue.textContent.replace('$', '').replace(',', ''));
        
        const newLocked = currentLocked + Math.floor(Math.random() * 100) - 50;
        const newTips = currentTips + Math.floor(Math.random() * 50) - 25;
        
        lockedValue.textContent = '$' + newLocked.toLocaleString();
        tipsValue.textContent = '$' + newTips.toLocaleString();
    }

    // Update stats every 5 seconds
    setInterval(updateStats, 5000);
}); 