# Payment Method Icons

Place your payment method icons in this directory using the following specifications:

## Icon Requirements
- Size: 64x64 pixels (displays at 32x32)
- Format: PNG with transparency
- Background: Transparent
- Colors: Light colors (white/light gray preferred)
- Padding: 2-4 pixels around edges

## File Names
- doge.png (Dogecoin)
- bells.png (Bells)
- bsv.png (Bitcoin SV)
- bch.png (Bitcoin Cash)
- btc.png (Bitcoin)
- ltc.png (Litecoin)

## Design Guidelines
1. Use simple, clean designs that are recognizable at small sizes
2. Maintain consistent style across all icons
3. Use official currency logos when available
4. Ensure good visibility on dark backgrounds
5. Test icons at both actual size (32x32) and retina size (64x64) 