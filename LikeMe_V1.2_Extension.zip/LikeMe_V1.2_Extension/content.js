let heart = null;
let toggleButton = null;
let currentTarget = null;
let isEnabled = true;
let moveTimeout = null;
let lastPosition = { x: 0, y: 0 };
let lastMousePosition = { x: 0, y: 0 };
let mouseMovementHistory = [];
const MOVEMENT_HISTORY_SIZE = 5;
let isMovingTowardsHeart = false;

// Global variables for toast timing
let toastTimeout = null;
let activeToast = null;
let toastInteractionTimeout = null;

// Carousel state
const carouselState = {
    lock: { currentIndex: 0, items: [], isDragging: false, startY: 0, currentTranslate: 0 },
    tip: { currentIndex: 0, items: [], isDragging: false, startY: 0, currentTranslate: 0, username: null, avatar: null }
};

// Platform configuration
let platformConfig = null;

// Track last action and scroll position
let lastAction = {
    type: null,
    amount: null
};
let lastScrollPosition = 0;

// Track flow state
let flowState = {
    isActive: false,
    originalTarget: null,
    originalUsername: null,
    actions: {
        lock: null,
        tip: null
    }
};

// Separate state for heart tracking
let heartState = {
    isLocked: false,
    currentTarget: null
};

// Load platform configuration
function loadPlatformConfig() {
    console.log('LikeMe: Loading platform configuration...');
    const configUrl = chrome.runtime.getURL('platform-config.json');
    console.log('LikeMe: Config URL:', configUrl);

    fetch(configUrl)
        .then(response => response.json())
        .then(config => {
            console.log('LikeMe: Configuration loaded successfully');
            platformConfig = config;
            initializeExtension();
        })
        .catch(error => {
            console.error('LikeMe: Error loading platform configuration:', error);
            // Fall back to generic configuration
            platformConfig = {
                generic: {
                    enabled: true,
                    elements: {
                        share: {
                            enabled: true,
                            selectors: ['[data-share]', '[aria-label*="share"]', '.share-button'],
                            icon: '🔄',
                            type: 'Share'
                        }
                    }
                }
            };
            initializeExtension();
        });
}

// Simplified platform detection
function getCurrentPlatform() {
    const hostname = window.location.hostname;
    if (hostname.includes('twitter.com') || hostname.includes('x.com')) {
        return 'x';
    }
    return null;
}

// Add this function to reset tutorial state
function resetTutorialState() {
    chrome.storage.local.remove(['likemeTutorialShown'], function() {
        console.log('LikeMe: Tutorial state reset');
        createTutorialModal();
    });
}

// Simplified initialization
function initializeExtension() {
    console.log('LikeMe: Initializing extension...');
    
    // Only initialize if we're on a supported platform
    const platform = getCurrentPlatform();
    if (!platform) {
        console.log('LikeMe: Not a supported platform');
        return;
    }

    // Get initial state before creating elements
    chrome.storage.local.get(['likemeEnabled', 'likemeTutorialShown'], function(result) {
        isEnabled = result.likemeEnabled !== false;
        
        createHeart();
        createModals();
        createToggleButton();
        setupPostEventListeners();
        setupScrollObserver();
        setupResizeObserver();
        
        // Apply initial state
        if (!isEnabled && heart) {
            heart.style.display = 'none';
            heart.classList.add('disabled');
        }

        // Show tutorial if it hasn't been shown before
        if (!result.likemeTutorialShown) {
            createTutorialModal();
        }
    });
}

// Simplified heart creation
function createHeart() {
    if (heart) return;
    
    heart = document.createElement('div');
    heart.className = 'likeme-heart' + (!isEnabled ? ' disabled' : '');
    heart.style.display = !isEnabled ? 'none' : '';
    // Removed inline transform, now handled by CSS
    heart.innerHTML = `
        <svg viewBox="0 0 24 24">
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
        </svg>
    `;

    document.body.appendChild(heart);
    heart.addEventListener('click', handleHeartClick);

    // Add toast styles to the document
    const style = document.createElement('style');
    style.textContent = `
        .likeme-toast {
            position: relative;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: rgb(0, 0, 0);
            border-radius: 16px;
            padding: 20px 20px 20px 20px; /* uniform padding */
            box-shadow: rgb(255 255 255 / 20%) 0px 0px 15px, rgb(255 255 255 / 15%) 0px 0px 3px 1px;
            z-index: 10000;
            opacity: 0;
            transition: all 0.2s ease;
            width: 600px;
            border: 1px solid rgb(47, 51, 54);
        }
        .likeme-toast-header {
            display: flex;
            align-items: center;
            justify-content: flex-start;
            margin-bottom: 20px;
            padding-right: 0;
        }
        .likeme-toast-close {
            position: absolute;
            top: 16px;
            right: 16px;
            margin-left: 0;
            flex-shrink: 0;
            z-index: 2;
        }
        .likeme-toast-actions {
            display: flex;
            gap: 16px;
            align-items: flex-start;
            justify-content: center;
            margin-right: 56px; /* leave space for close button */
        }
        .likeme-toast-action-group {
            display: flex;
            flex-direction: column;
            align-items: center;
            flex: 1;
            min-width: 0;
            max-width: 220px;
        }
        .likeme-toast-button {
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            min-width: 0;
        }
        .likeme-button-content {
            width: 100%;
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: center;
            gap: 12px;
            padding: 15px 0;
        }
        .likeme-button-amount-below {
            margin-top: 4px;
            font-size: 13px;
            color: rgb(247, 249, 249);
            opacity: 0.85;
            text-align: center;
            word-break: break-all;
            font-weight: 500;
            width: 100%;
        }
        @media (max-width: 640px) {
            .likeme-toast {
                padding: 16px 8px 16px 8px;
                width: calc(100% - 16px);
            }
            .likeme-toast-header {
                padding-right: 0;
            }
            .likeme-toast-close {
                top: 8px;
                right: 8px;
            }
            .likeme-toast-actions {
                flex-direction: column;
                gap: 8px;
                margin-right: 0;
            }
            .likeme-toast-action-group {
                max-width: none;
                width: 100%;
            }
            .likeme-toast-button {
                width: 100%;
            }
        }
        
        .likeme-toast-icon {
            font-size: 18px;
            line-height: 18px;
            flex: 0 0 auto;
        }

        .likeme-button-label {
            font-weight: 700;
            font-size: 15px;
            flex: 0 1 auto;
            text-align: left;
            min-width: 0;
            overflow: hidden;
            text-overflow: ellipsis;
            margin-right: auto;
            padding-right: 8px;
        }

        .likeme-button-amount {
            color: inherit;
            font-size: 15px;
            font-weight: 400;
            flex: 0 0 auto;
            padding-left: 16px;
            margin-left: 8px;
            border-left: 1px solid rgba(255, 255, 255, 0.2);
            min-width: fit-content;
        }
        
        .likeme-lock-button .likeme-button-amount {
            border-left-color: rgba(0, 0, 0, 0.1);
        }
        
        .likeme-lock-button {
            background-color: rgb(239, 243, 244);
            color: rgb(15, 20, 25);
            padding-right: 28px;
        }
        
        .likeme-tip-button {
            background-color: rgb(255, 77, 124);
            color: white;
            padding-right: 28px;
        }
        
        .likeme-toast-close:hover {
            background-color: rgba(15, 20, 25, 0.1);
            color: rgb(15, 20, 25);
        }
        
        @media (max-width: 640px) {
            .likeme-toast {
                bottom: 16px;
                width: calc(100% - 32px);
                max-width: 600px;
                padding: 16px;
            }
            
            .likeme-toast-actions {
                flex-direction: column;
                gap: 12px;
            }
            
            .likeme-toast-button {
                width: 100%;
                max-width: none;
                padding: 12px 20px;
                min-height: 44px;
                justify-content: flex-start;
            }
            
            .likeme-button-amount {
                margin-left: auto;
                padding-left: 16px;
            }

            .likeme-button-label {
                max-width: 50%;
            }
        }

        .likeme-message-section {
            margin-top: 16px;
            border-top: 1px solid rgb(239, 243, 244);
            padding-top: 16px;
        }

        .likeme-message-checkbox {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            color: rgb(15, 20, 25);
            cursor: pointer;
            user-select: none;
            margin-bottom: 12px;
            font-weight: 500;
        }

        .likeme-message-checkbox input[type="checkbox"] {
            width: 16px;
            height: 16px;
            margin: 0;
            cursor: pointer;
        }

        .likeme-message-field {
            margin-top: 12px;
            background: white;
            border-radius: 8px;
            padding: 2px;
            border: 1px solid rgb(239, 243, 244);
        }

        .likeme-message-input {
            width: 100%;
            min-height: 80px;
            max-height: 80px;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            line-height: 1.5;
            color: rgb(15, 20, 25);
            resize: none;
            background: white;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            overflow-y: auto;
            scrollbar-width: none; /* Firefox */
            -ms-overflow-style: none; /* IE and Edge */
        }

        .likeme-message-input::-webkit-scrollbar {
            display: none; /* Chrome, Safari and Opera */
        }

        .likeme-message-input:focus {
            outline: none;
            background: white;
        }

        .likeme-message-input::placeholder {
            color: rgb(83, 100, 113);
        }

        .likeme-message-field:focus-within {
            border-color: rgb(255, 77, 124);
            box-shadow: rgb(255 77 124 / 20%) 0px 0px 0px 1px;
        }
    `;
    document.head.appendChild(style);

    // Add or update the style block for .likeme-tip-avatar
    style.textContent += `
    .likeme-tip-avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      margin: 0 1px;
      vertical-align: middle;
      box-shadow: 0 2px 8px rgba(0,0,0,0.10);
    }
    `;

    // Add this to the style block for heart scaling
    style.textContent += `
    .likeme-heart {
      transform: scale(0.8) !important;
      transform-origin: center center;
    }
    /* Hide number input spinners for all browsers */
    .likeme-custom-amount-input::-webkit-inner-spin-button,
    .likeme-custom-amount-input::-webkit-outer-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }
    .likeme-custom-amount-input {
      -moz-appearance: textfield;
    }
    /* Make payment icons round and remove square background */
    .likeme-payment-option,
    .likeme-payment-selected {
      background: none !important;
      border-radius: 50% !important;
      padding: 0 !important;
      box-shadow: none !important;
      border: none !important;
      width: 48px;
      height: 48px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .likeme-payment-option img,
    .likeme-payment-selected img {
      border-radius: 50%;
      width: 40px;
      height: 40px;
      background: none;
      box-shadow: none;
      border: 2px solid #fff;
    }
    .likeme-payment-options {
      display: none !important;
    }
    .likeme-payment-options.show {
      display: grid !important;
      grid-template-columns: repeat(2, 1fr);
      gap: 20px !important;
      justify-items: center;
      align-items: center;
      padding: 12px 8px !important;
    }
    /* Equal toast action buttons */
    .likeme-toast-actions {
      display: flex;
      gap: 16px;
      align-items: center;
      justify-content: center;
    }
    .likeme-toast-action-group {
      flex: 1 1 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      min-width: 0;
    }
    .likeme-toast-button {
      width: 100%;
      min-width: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 24px;
      padding: 0;
      height: 48px;
      font-size: 16px;
      font-weight: 700;
      transition: background 0.2s;
    }
    .likeme-lock-button .likeme-button-content,
    .likeme-tip-button .likeme-button-content {
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
      padding: 0 32px;
      height: 48px;
      border-radius: 24px;
    }
    .likeme-lock-button {
      background: #23272a;
      color: #fff;
    }
    .likeme-tip-button {
      background: #ff4d7c;
      color: #fff;
    }
    .likeme-button-amount-below {
      min-height: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 13px;
      color: rgb(247, 249, 249);
      opacity: 0.85;
      text-align: center;
      word-break: break-all;
      font-weight: 500;
      width: 100%;
    }
    `;
}

// Create modals with original design
function createModals() {
    // Lock Modal
    const lockModal = document.createElement('div');
    lockModal.className = 'likeme-modal';
    lockModal.id = 'lockModal';
    lockModal.setAttribute('role', 'dialog');
    lockModal.setAttribute('aria-label', 'Lock Content');
    lockModal.innerHTML = `
        <div class="likeme-modal-content">
            <div class="likeme-payment-selector">
                <div class="likeme-payment-dropdown">
                    <div class="likeme-payment-selected" data-method="doge" data-tooltip="Dogecoin">
                        <img src="${chrome.runtime.getURL('assets/payment-methods/doge.png')}" alt="Dogecoin">
                    </div>
                    <div class="likeme-payment-options">
                        <div class="likeme-payment-option active" data-method="doge" data-tooltip="Dogecoin">
                            <img src="${chrome.runtime.getURL('assets/payment-methods/doge.png')}" alt="Dogecoin">
                        </div>
                        <div class="likeme-payment-option" data-method="bells" data-tooltip="Bells">
                            <img src="${chrome.runtime.getURL('assets/payment-methods/bells.png')}" alt="Bells">
                        </div>
                        <div class="likeme-payment-option" data-method="bsv" data-tooltip="Bitcoin SV">
                            <img src="${chrome.runtime.getURL('assets/payment-methods/bsv.png')}" alt="Bitcoin SV">
                        </div>
                        <div class="likeme-payment-option" data-method="bch" data-tooltip="Bitcoin Cash">
                            <img src="${chrome.runtime.getURL('assets/payment-methods/bch.png')}" alt="Bitcoin Cash">
                        </div>
                        <div class="likeme-payment-option" data-method="btc" data-tooltip="Bitcoin">
                            <img src="${chrome.runtime.getURL('assets/payment-methods/btc.png')}" alt="Bitcoin">
                        </div>
                        <div class="likeme-payment-option" data-method="ltc" data-tooltip="Litecoin">
                            <img src="${chrome.runtime.getURL('assets/payment-methods/ltc.png')}" alt="Litecoin">
                        </div>
                    </div>
                </div>
            </div>
            <div class="likeme-modal-title" role="heading" aria-level="1">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                </svg>
                Lock Amount: $1000
            </div>
            <div class="likeme-amount-carousel" id="lockCarousel" role="listbox" aria-label="Lock amount selection"></div>
            <div class="likeme-custom-amount">
                <input type="number" class="likeme-custom-amount-input" id="lockCustomAmount" placeholder="Enter amount in USD" aria-label="Custom lock amount">
            </div>
            <div class="likeme-message-section">
                <label class="likeme-message-checkbox">
                    <input type="checkbox" id="lockMessageCheckbox" aria-label="Enable comment">
                    <span>Post comment</span>
                </label>
                <div class="likeme-message-field" id="lockMessageField" style="display: none;">
                    <div class="likeme-message-input-wrapper">
                        <textarea class="likeme-message-input" id="lockMessageText" 
                            placeholder="Enter your comment"
                            aria-label="Comment text">Just locked this content with LikeMe! Great post 🔒</textarea>
                        <button class="likeme-clear-button" id="lockMessageClear" aria-label="Clear message">
                            <svg viewBox="0 0 24 24" width="16" height="16">
                                <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
            <div class="likeme-modal-actions">
                <button class="likeme-modal-button cancel" aria-label="Cancel">Cancel</button>
                <button class="likeme-modal-button confirm" aria-label="Lock Content">Lock</button>
            </div>
            <div class="likeme-brand">
                <div class="likeme-brand-heart">
                    <svg viewBox="0 0 24 24">
                        <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                    </svg>
                </div>
                LikeMe
            </div>
            <div class="likeme-disclaimer">
                LikeMe is not affiliated with, endorsed by, or associated with X (formerly Twitter)
            </div>
        </div>
    `;

    // Tip Modal
    const tipModal = document.createElement('div');
    tipModal.className = 'likeme-modal';
    tipModal.id = 'tipModal';
    tipModal.setAttribute('role', 'dialog');
    tipModal.setAttribute('aria-label', 'Send Tip');
    tipModal.innerHTML = `
        <div class="likeme-modal-content">
            <div class="likeme-payment-selector">
                <div class="likeme-payment-dropdown">
                    <div class="likeme-payment-selected" data-method="doge" data-tooltip="Dogecoin">
                        <img src="${chrome.runtime.getURL('assets/payment-methods/doge.png')}" alt="Dogecoin">
                    </div>
                    <div class="likeme-payment-options">
                        <div class="likeme-payment-option active" data-method="doge" data-tooltip="Dogecoin">
                            <img src="${chrome.runtime.getURL('assets/payment-methods/doge.png')}" alt="Dogecoin">
                        </div>
                        <div class="likeme-payment-option" data-method="bells" data-tooltip="Bells">
                            <img src="${chrome.runtime.getURL('assets/payment-methods/bells.png')}" alt="Bells">
                        </div>
                        <div class="likeme-payment-option" data-method="bsv" data-tooltip="Bitcoin SV">
                            <img src="${chrome.runtime.getURL('assets/payment-methods/bsv.png')}" alt="Bitcoin SV">
                        </div>
                        <div class="likeme-payment-option" data-method="bch" data-tooltip="Bitcoin Cash">
                            <img src="${chrome.runtime.getURL('assets/payment-methods/bch.png')}" alt="Bitcoin Cash">
                        </div>
                        <div class="likeme-payment-option" data-method="btc" data-tooltip="Bitcoin">
                            <img src="${chrome.runtime.getURL('assets/payment-methods/btc.png')}" alt="Bitcoin">
                        </div>
                        <div class="likeme-payment-option" data-method="ltc" data-tooltip="Litecoin">
                            <img src="${chrome.runtime.getURL('assets/payment-methods/ltc.png')}" alt="Litecoin">
                        </div>
                    </div>
                </div>
            </div>
            <div class="likeme-modal-title" role="heading" aria-level="1">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                    <path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                </svg>
                Tip Amount: $1000
            </div>
            <div class="likeme-amount-carousel" id="tipCarousel" role="listbox" aria-label="Tip amount selection"></div>
            <div class="likeme-custom-amount">
                <input type="number" class="likeme-custom-amount-input" id="tipCustomAmount" placeholder="Enter amount in USD" aria-label="Custom tip amount">
            </div>
            <div class="likeme-message-section">
                <label class="likeme-message-checkbox">
                    <input type="checkbox" id="tipMessageCheckbox" aria-label="Enable comment">
                    <span>Post comment</span>
                </label>
                <div class="likeme-message-field" id="tipMessageField" style="display: none;">
                    <div class="likeme-message-input-wrapper">
                        <textarea class="likeme-message-input" id="tipMessageText" 
                            placeholder="Enter your comment"
                            aria-label="Comment text">Just sent a tip with LikeMe! Love your content ⚡</textarea>
                        <button class="likeme-clear-button" id="tipMessageClear" aria-label="Clear message">
                            <svg viewBox="0 0 24 24" width="16" height="16">
                                <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
            <div class="likeme-modal-actions">
                <button class="likeme-modal-button cancel" aria-label="Cancel">Cancel</button>
                <button class="likeme-modal-button confirm" aria-label="Send Tip">Pay</button>
            </div>
            <div class="likeme-brand">
                <div class="likeme-brand-heart">
                    <svg viewBox="0 0 24 24">
                        <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                    </svg>
                </div>
                LikeMe
            </div>
            <div class="likeme-disclaimer">
                LikeMe is not affiliated with, endorsed by, or associated with X (formerly Twitter)
            </div>
        </div>
    `;

    // Update styles
    const style = document.createElement('style');
    style.textContent += `
        .likeme-brand {
            color: rgb(247, 249, 249);
            font-size: 16px;
            font-weight: 700;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-top: 32px;
            padding-top: 24px;
            border-top: 1px solid rgb(47, 51, 54);
            opacity: 0.8;
            transition: opacity 0.3s ease;
        }

        .likeme-brand:hover {
            opacity: 1;
        }

        .likeme-brand-heart {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .likeme-brand-heart svg {
            width: 16px;
            height: 16px;
            fill: rgb(255, 77, 124);
            transition: fill 0.3s ease;
        }

        .likeme-brand:hover .likeme-brand-heart {
            transform: scale(1.1);
        }

        .likeme-brand:hover .likeme-brand-heart svg {
            fill: rgb(255, 31, 90);
        }

        .likeme-modal-header {
            margin-bottom: 24px;
        }

        .likeme-modal-title {
            font-size: 18px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 12px;
            color: rgb(247, 249, 249);
        }

        .likeme-modal-title svg {
            stroke: rgb(247, 249, 249);
        }

        .likeme-amount-carousel {
            height: 200px;
            transition: visibility 0.3s ease, opacity 0.3s ease;
            margin: 20px 0;
            background: rgb(0, 0, 0);
        }

        .likeme-amount-item {
            color: rgb(247, 249, 249);
            font-size: 20px;
            font-weight: 700;
            padding: 12px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .likeme-amount-item:hover {
            background: rgba(239, 243, 244, 0.1);
        }

        .likeme-amount-item.active {
            color: rgb(255, 77, 124);
        }

        .likeme-custom-amount {
            margin: 20px 0;
        }

        .likeme-custom-amount-label {
            color: rgb(247, 249, 249);
            font-size: 15px;
            margin-bottom: 8px;
            display: block;
            font-weight: 400;
        }

        .likeme-custom-amount-input {
            width: 100%;
            padding: 12px;
            border: 1px solid rgb(47, 51, 54);
            border-radius: 4px;
            background: rgb(0, 0, 0);
            color: rgb(247, 249, 249);
            font-size: 15px;
            transition: all 0.2s ease;
        }

        .likeme-custom-amount-input:focus {
            border-color: rgb(255, 77, 124);
            box-shadow: rgb(255 77 124 / 20%) 0px 0px 0px 1px;
        }

        .likeme-message-section {
            margin-top: 24px;
            border-top: 1px solid rgb(47, 51, 54);
            padding-top: 24px;
        }

        .likeme-message-checkbox {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 15px;
            cursor: pointer;
            user-select: none;
            margin-bottom: 12px;
        }

        .likeme-message-checkbox span {
            color: rgb(247, 249, 249) !important;
            font-weight: 400;
            opacity: 1 !important;
        }

        .likeme-message-checkbox input[type="checkbox"] {
            width: 18px;
            height: 18px;
            margin: 0;
            cursor: pointer;
            border-radius: 4px;
            border: 2px solid rgb(113, 118, 123);
            background: rgb(0, 0, 0);
            appearance: none;
            -webkit-appearance: none;
            position: relative;
            transition: all 0.2s ease;
        }

        .likeme-message-checkbox input[type="checkbox"]:hover {
            border-color: rgb(239, 243, 244);
        }

        .likeme-message-checkbox input[type="checkbox"]:checked {
            background: rgb(255, 77, 124);
            border-color: rgb(255, 77, 124);
        }

        .likeme-message-checkbox input[type="checkbox"]:checked::after {
            content: "✓";
            position: absolute;
            color: rgb(255, 255, 255);
            font-size: 12px;
            left: 3px;
            top: 0px;
        }

        .likeme-message-field {
            margin-top: 12px;
            background: rgb(0, 0, 0);
            border-radius: 8px;
            padding: 2px;
            border: 1px solid rgb(47, 51, 54);
        }

        .likeme-message-input {
            width: 100%;
            min-height: 80px;
            max-height: 80px;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            line-height: 1.5;
            color: rgb(247, 249, 249);
            resize: none;
            background: rgb(0, 0, 0);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        }

        .likeme-message-input:focus {
            outline: none;
            background: rgb(0, 0, 0);
        }

        .likeme-message-input::placeholder {
            color: rgb(113, 118, 123);
        }

        .likeme-message-field:focus-within {
            border-color: rgb(255, 77, 124);
            box-shadow: rgb(255 77 124 / 20%) 0px 0px 0px 1px;
        }

        .likeme-modal-actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
        }

        .likeme-modal-button {
            flex: 1;
            padding: 12px 24px;
            border: none;
            border-radius: 9999px;
            cursor: pointer;
            font-size: 15px;
            font-weight: 700;
            transition: background-color 0.2s ease;
            min-height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
        }

        .likeme-modal-button.cancel {
            background: transparent;
            border: 1px solid rgb(83, 100, 113);
            color: rgb(247, 249, 249);
        }

        .likeme-modal-button.cancel:hover {
            background: rgba(239, 243, 244, 0.1);
        }

        .likeme-modal-button.confirm {
            background: rgb(255, 77, 124);
            border-color: rgb(255, 77, 124);
        }

        .likeme-modal-button.confirm:hover {
            background: rgb(255, 31, 90);
        }

        .likeme-clear-button {
            position: absolute;
            top: 8px;
            right: 8px;
            width: 24px;
            height: 24px;
            border: none;
            background: rgba(255, 77, 124, 0.1);
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0;
            transition: all 0.2s ease;
            opacity: 0.8;
        }

        .likeme-clear-button:hover {
            background: rgba(255, 77, 124, 0.2);
            opacity: 1;
        }

        .likeme-clear-button svg {
            fill: rgb(255, 77, 124);
        }

        /* Toast Styles */
        .likeme-toast {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: rgb(0, 0, 0);
            border-radius: 16px;
            padding: 16px;
            box-shadow: rgb(255 255 255 / 20%) 0px 0px 15px, rgb(255 255 255 / 15%) 0px 0px 3px 1px;
            z-index: 10000;
            opacity: 0;
            transition: all 0.2s ease;
            width: 600px;
            border: 1px solid rgb(47, 51, 54);
        }

        .likeme-toast.show {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
        }

        .likeme-toast-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 16px;
        }

        .likeme-toast-message {
            display: flex;
            align-items: center;
            gap: 8px;
            color: rgb(247, 249, 249);
            font-size: 15px;
            font-weight: 700;
        }

        .likeme-toast-close {
            width: 34px;
            height: 34px;
            border: none;
            background: transparent;
            color: rgb(113, 118, 123);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            padding: 0;
            transition: all 0.2s ease;
            margin: -8px;
        }

        .likeme-toast-close:hover {
            color: rgb(247, 249, 249);
            background: rgba(239, 243, 244, 0.1);
        }

        .likeme-toast-actions {
            display: flex;
            gap: 12px;
        }

        .likeme-toast-button {
            flex: 1;
            border: none;
            border-radius: 9999px;
            cursor: pointer;
            padding: 0;
            transition: background-color 0.2s ease;
            overflow: hidden;
            background: none;
        }

        .likeme-button-content {
            display: flex;
            align-items: center;
            padding: 15px 24px;
            gap: 12px;
            width: 100%;
            height: 100%;
            transition: background-color 0.2s ease;
        }

        .likeme-lock-button .likeme-button-content {
            background: rgb(32, 35, 39);
            color: rgb(247, 249, 249);
        }

        .likeme-lock-button:hover .likeme-button-content {
            background: rgb(39, 44, 48);
        }

        .likeme-tip-button .likeme-button-content {
            background: rgb(255, 77, 124);
            color: white;
        }

        .likeme-tip-button:hover .likeme-button-content {
            background: rgb(255, 31, 90);
        }

        .likeme-button-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 700;
            min-width: 18px;
        }

        .likeme-button-label {
            font-size: 15px;
            font-weight: 700;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            flex: 1;
        }

        .likeme-button-amount {
            padding-left: 12px;
            margin-left: 12px;
            border-left: 1px solid rgba(255, 255, 255, 0.2);
            font-size: 15px;
            font-weight: 400;
        }

        @media (max-width: 640px) {
            .likeme-toast {
                bottom: 16px;
                width: calc(100% - 32px);
                padding: 16px;
            }

            .likeme-toast-actions {
                flex-direction: column;
                gap: 8px;
            }
            
            .likeme-button-content {
                justify-content: flex-start;
            }

            .likeme-button-amount {
                margin-left: auto;
            }
        }
    `;
    document.head.appendChild(style);

    document.body.appendChild(lockModal);
    document.body.appendChild(tipModal);

    // Initialize carousels
    initializeCarousels();

    // Add message checkbox handlers
    ['lock', 'tip'].forEach(type => {
        const checkbox = document.getElementById(`${type}MessageCheckbox`);
        const field = document.getElementById(`${type}MessageField`);
        const clearButton = document.getElementById(`${type}MessageClear`);
        const textarea = document.getElementById(`${type}MessageText`);
        
        // Set initial state
        field.style.display = 'none';
        
        checkbox.addEventListener('change', () => {
            field.style.display = checkbox.checked ? 'block' : 'none';
            // --- BEGIN: Show post snippet above comment section ---
            const modalContent = field.closest('.likeme-modal-content');
            let snippetDiv = modalContent.querySelector('.likeme-post-snippet');
            if (checkbox.checked) {
                if (!snippetDiv) {
                    snippetDiv = document.createElement('div');
                    snippetDiv.className = 'likeme-post-snippet';
                    snippetDiv.style.cssText = 'margin-bottom:12px;padding:8px 10px;background:rgba(255,255,255,0.04);border-radius:8px;font-size:14px;color:#aaa;line-height:1.4;max-height:60px;overflow-y:auto;display:flex;align-items:flex-start;gap:10px;';
                    // Insert above the message section
                    const messageSection = modalContent.querySelector('.likeme-message-section');
                    modalContent.insertBefore(snippetDiv, messageSection);
                }
                let post = flowState.originalTarget;
                let snippet = '';
                let avatarUrl = null;
                if (post) {
                    let textElem = post.querySelector('div[lang]');
                    snippet = textElem ? textElem.textContent.trim() : post.textContent.trim();
                    avatarUrl = getPostAvatar(post);
                }
                snippetDiv.innerHTML =
                    (avatarUrl ? `<img src="${avatarUrl}" alt="avatar" class="likeme-tip-avatar" style="margin-right:8px;">` : '') +
                    `<span style="display:block;white-space:pre-line;">${snippet || 'No post content found.'}</span>`;
            } else if (snippetDiv) {
                snippetDiv.remove();
            }
            // --- END: Show post snippet above comment section ---
            if (checkbox.checked) {
                textarea?.focus();
            }
            // Change confirm button text for tip modal
            if (type === 'tip') {
                const tipModal = document.getElementById('tipModal');
                const confirmButton = tipModal.querySelector('.likeme-modal-button.confirm');
                if (confirmButton) {
                    confirmButton.textContent = checkbox.checked ? 'Pay & Reply' : 'Pay';
                }
            }
            // Change confirm button text for lock modal
            if (type === 'lock') {
                const lockModal = document.getElementById('lockModal');
                const confirmButton = lockModal.querySelector('.likeme-modal-button.confirm');
                if (confirmButton) {
                    confirmButton.textContent = checkbox.checked ? 'Lock & Reply' : 'Lock';
                }
            }
        });

        // Add clear button handler
        clearButton?.addEventListener('click', () => {
            if (textarea) {
                textarea.value = '';
                textarea.focus();
            }
        });
    });

    // Add modal close handlers
    [lockModal, tipModal].forEach(modal => {
        const type = modal.id.replace('Modal', '');
        
        // Close on backdrop click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeModal(modal.id);
            }
        });

        // Add button handlers
        const cancelButton = modal.querySelector('.cancel');
        const confirmButton = modal.querySelector('.confirm');

        cancelButton.addEventListener('click', () => closeModal(modal.id));
        confirmButton.addEventListener('click', () => {
            if (type === 'lock') {
                confirmLock();
            } else {
                confirmTip();
            }
        });
    });

    // Add payment method selection functionality
    initializePaymentMethods();
}

// Generate amount items for carousel
function generateAmountItems() {
    const amounts = [0.01, 1, 2, 3, 4, 5, 10, 25, 50, 100];
    return amounts.map(amount => {
        const formattedAmount = amount < 1 ? `$${amount.toFixed(2)}` : `$${amount.toLocaleString()}`;
        return `<div class="likeme-amount-item" data-value="${amount}" data-base-amount="${amount}">${formattedAmount}</div>`;
    }).join('');
}

// Initialize carousels
function initializeCarousels() {
    ['lock', 'tip'].forEach(type => {
        const carousel = document.getElementById(`${type}Carousel`);
        carousel.innerHTML = `<div class="likeme-carousel-container">${generateAmountItems()}</div>`;
        const container = carousel.querySelector('.likeme-carousel-container');
        carouselState[type].items = Array.from(container.querySelectorAll('.likeme-amount-item'));
        
        // Add event listeners
        carousel.addEventListener('mousedown', (e) => startDragging(e, type));
        carousel.addEventListener('touchstart', (e) => startDragging(e, type), { passive: false });
        carousel.addEventListener('mousemove', (e) => drag(e, type));
        carousel.addEventListener('touchmove', (e) => drag(e, type), { passive: false });
        carousel.addEventListener('mouseup', () => endDragging(type));
        carousel.addEventListener('touchend', () => endDragging(type));
        carousel.addEventListener('mouseleave', () => endDragging(type));
        carousel.addEventListener('wheel', (e) => handleWheel(e, type), { passive: false });

        // Initialize display
        updateCarouselDisplay(type);
    });
}

// Carousel interaction functions
function startDragging(e, type) {
    const state = carouselState[type];
    if (e.target.classList.contains('likeme-amount-item')) {
        const index = state.items.indexOf(e.target);
        if (index !== -1) {
            state.currentIndex = index;
            updateCarouselDisplay(type);
        }
        return;
    }
    
    e.preventDefault();
    state.isDragging = true;
    state.startY = e.type === 'mousedown' ? e.clientY : e.touches[0].clientY;
    state.currentTranslate = 0;
}

function drag(e, type) {
    const state = carouselState[type];
    if (!state.isDragging) return;
    
    e.preventDefault();
    const currentY = e.type === 'mousemove' ? e.clientY : e.touches[0].clientY;
    state.currentTranslate = currentY - state.startY;

    if (Math.abs(state.currentTranslate) > 40) {
        moveCarousel(type, state.currentTranslate > 0 ? -1 : 1);
        endDragging(type);
    }
}

function endDragging(type) {
    carouselState[type].isDragging = false;
}

function handleWheel(e, type) {
    e.preventDefault();
    
    // Get the modal
    const modal = document.getElementById(`${type}Modal`);
    const customInput = modal.querySelector('.likeme-custom-amount-input');
    
    // If there's a custom amount, clear it first
    if (customInput && customInput.value) {
        customInput.value = '';
        const carouselContainer = modal.querySelector('.likeme-amount-carousel');
        
        // Remove custom amount item if it exists
        const customAmountItem = carouselContainer.querySelector('.likeme-amount-item.custom');
        if (customAmountItem) {
            customAmountItem.remove();
        }

        // Show all original carousel items
        carouselContainer.querySelectorAll('.likeme-amount-item:not(.custom)').forEach(item => {
            item.style.display = 'flex';
        });
    }
    
    moveCarousel(type, e.deltaY > 0 ? 1 : -1);
}

function moveCarousel(type, direction) {
    const state = carouselState[type];
    const totalItems = state.items.length;
    let newIndex = state.currentIndex + direction;
    
    if (newIndex >= totalItems) newIndex = 0;
    if (newIndex < 0) newIndex = totalItems - 1;
    
    if (newIndex !== state.currentIndex) {
        state.currentIndex = newIndex;
        
        // Get the modal and selected payment method
        const modal = document.getElementById(`${type}Modal`);
        const selectedMethod = modal.getAttribute('data-selected-payment') || 'doge';
        
        // Get the current amount from the active carousel item
        const activeItem = state.items[newIndex];
        const amount = activeItem.getAttribute('data-base-amount');
        
        // Clear any custom amount input and restore carousel items
        const customInput = modal.querySelector('.likeme-custom-amount-input');
        const carouselContainer = modal.querySelector('.likeme-amount-carousel');
        if (customInput) {
            customInput.value = '';
        }
        
        // Remove custom amount item if it exists
        const customAmountItem = carouselContainer.querySelector('.likeme-amount-item.custom');
        if (customAmountItem) {
            customAmountItem.remove();
        }

        // Show all original carousel items
        carouselContainer.querySelectorAll('.likeme-amount-item:not(.custom)').forEach(item => {
            item.style.display = 'flex';
        });
        
        // Update the carousel display first
        updateCarouselDisplay(type);
        
        // Then update the conversion display
        updateCustomAmountConversion(amount, selectedMethod, modal);
    }
}

// Update carousel display with username
function updateCarouselDisplay(type) {
    const state = carouselState[type];
    const items = state.items;
    const currentIndex = state.currentIndex;
    
    // Get the modal
    const modal = document.getElementById(`${type}Modal`);
    
    // Update modal title
    const modalTitle = modal.querySelector('.likeme-modal-title');
    const currentAmount = parseFloat(items[currentIndex].dataset.baseAmount);
    const formattedAmount = currentAmount < 1 ? 
        `$${currentAmount.toFixed(2)}` : 
        `$${currentAmount.toLocaleString()}`;
    
    if (type === 'tip') {
        const avatar = state.avatar ? `<img src="${state.avatar}" alt="avatar" class="likeme-tip-avatar">` : '';
        modalTitle.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
            </svg>
            Tip/Pay ${avatar}@${state.username}: ${formattedAmount}
        `;
    } else {
        modalTitle.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
            </svg>
            Lock Amount: ${formattedAmount}
        `;
    }

    // Update message text for tips when carousel amount changes
    if (type === 'tip') {
        const messageText = modal.querySelector('.likeme-message-input');
        if (messageText) {
            messageText.value = `Just sent you ${formattedAmount} with @LikeMe`;
        }
    }

    // Update carousel items display
    items.forEach((item, index) => {
        item.className = 'likeme-amount-item';
        
        const diff = index - currentIndex;
        
        if (Math.abs(diff) <= 2) {
            item.classList.add('visible');
            
            if (diff === 0) {
                item.classList.add('active');
            } else if (diff === -1) {
                item.classList.add('above-1');
            } else if (diff === -2) {
                item.classList.add('above-2');
            } else if (diff === 1) {
                item.classList.add('below-1');
            } else if (diff === 2) {
                item.classList.add('below-2');
            }
        }
    });
}

// Show modal with proper state
function showModal(type, username = null) {
    const modal = document.getElementById(`${type}Modal`);
    // Remove any lingering post snippet from previous sessions
    const modalContent = modal.querySelector('.likeme-modal-content');
    if (modalContent) {
        const oldSnippet = modalContent.querySelector('.likeme-post-snippet');
        if (oldSnippet) oldSnippet.remove();
    }
    
    // Store current scroll position
    lastScrollPosition = window.scrollY;
    
    // Reset modal state
    const customAmount = modal.querySelector('.likeme-custom-amount-input');
    const messageCheckbox = modal.querySelector('.likeme-message-checkbox input');
    const messageField = modal.querySelector('.likeme-message-field');
    const messageText = modal.querySelector('.likeme-message-input');
    const carousel = modal.querySelector('.likeme-amount-carousel');
    
    // Add conversion display element after the custom amount input
    const customAmountSection = modal.querySelector('.likeme-custom-amount');
    let conversionDisplay = customAmountSection.querySelector('.likeme-conversion-display');
    if (!conversionDisplay) {
        conversionDisplay = document.createElement('div');
        conversionDisplay.className = 'likeme-conversion-display';
        customAmountSection.appendChild(conversionDisplay);
    }
    
    // --- RESET STATE ---
    // Clear custom amount input
    customAmount.value = '';
    // Remove custom amount item from carousel
    const customAmountItem = carousel.querySelector('.likeme-amount-item.custom');
    if (customAmountItem) customAmountItem.remove();
    // Show all original carousel items
    carousel.querySelectorAll('.likeme-amount-item:not(.custom)').forEach(item => {
        item.style.display = 'flex';
    });
    // Reset carousel index
    carouselState[type].currentIndex = 0;
    // --- END RESET ---
    
    // Always reset comment UI state
    messageCheckbox.checked = false;
    messageField.style.display = 'none';
    if (type === 'tip') {
        const confirmButton = modal.querySelector('.likeme-modal-button.confirm');
        if (confirmButton) {
            confirmButton.textContent = 'Pay';
        }
    }
    carousel.style.visibility = 'visible';
    carousel.style.opacity = '1';
    
    // Function to update tip message with current amount
    const updateTipMessage = (amount) => {
        const formattedAmount = amount < 1 ? 
            `$${amount.toFixed(2)}` : 
            `$${amount.toLocaleString()}`;
        return `Just sent you ${formattedAmount} with @LikeMe`;
    };

    // Set initial message
    messageText.value = type === 'tip' ? 
        updateTipMessage(parseFloat(carouselState.tip.items[0].dataset.baseAmount)) :
        'Just shared using @LikeMe';
    // Also reset the textarea's defaultValue so clearing works
    messageText.defaultValue = messageText.value;

    // Store username in carousel state for tips
    if (type === 'tip') {
        carouselState.tip.username = username;
        // Try to get avatar from the original tweet element
        let avatarUrl = null;
        if (flowState && flowState.originalTarget) {
            avatarUrl = getPostAvatar(flowState.originalTarget);
        }
        carouselState.tip.avatar = avatarUrl;
    }

    // Add input handler for custom amount
    customAmount.oninput = (e) => {
        const value = e.target.value;
        const modalTitle = modal.querySelector('.likeme-modal-title');
        const carouselContainer = modal.querySelector('.likeme-amount-carousel');
        
        // Update conversion display
        const selectedMethod = modal.getAttribute('data-selected-payment') || 'doge';
        updateCustomAmountConversion(value, selectedMethod, modal);
        
        if (value && value.length > 0 && !isNaN(value)) {
            const numericValue = parseFloat(value);
            const formattedAmount = numericValue < 1 ? 
                `$${numericValue.toFixed(2)}` : 
                `$${numericValue.toLocaleString()}`;

            // Create or update custom amount item in carousel
            let customAmountItem = carouselContainer.querySelector('.likeme-amount-item.custom');
            if (!customAmountItem) {
                customAmountItem = document.createElement('div');
                customAmountItem.className = 'likeme-amount-item custom active';
                carouselContainer.appendChild(customAmountItem);
            }
            
            // Update custom amount item
            customAmountItem.setAttribute('data-value', numericValue);
            customAmountItem.setAttribute('data-base-amount', numericValue);
            customAmountItem.textContent = formattedAmount;

            // Hide other amount items
            carouselContainer.querySelectorAll('.likeme-amount-item:not(.custom)').forEach(item => {
                item.style.display = 'none';
            });
            
            // Show and position custom amount item
            customAmountItem.style.display = 'flex';
            customAmountItem.style.opacity = '1';
            customAmountItem.style.transform = 'translateY(0) scale(1)';

            // Update modal title
            if (type === 'tip') {
                const avatar = carouselState.tip.avatar ? `<img src="${carouselState.tip.avatar}" alt="avatar" class="likeme-tip-avatar">` : '';
                modalTitle.innerHTML = `
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                    </svg>
                    Tip/Pay ${avatar}@${carouselState.tip.username}: ${formattedAmount}
                `;
            } else {
                modalTitle.innerHTML = `
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                    </svg>
                    Lock Amount: ${formattedAmount}
                `;
            }
            // Update message text for tips
            if (type === 'tip') {
                messageText.value = updateTipMessage(numericValue);
            }
        } else {
            // Remove custom amount item if it exists
            const customAmountItem = carouselContainer.querySelector('.likeme-amount-item.custom');
            if (customAmountItem) {
                customAmountItem.remove();
            }

            // Show original amount items
            carouselContainer.querySelectorAll('.likeme-amount-item:not(.custom)').forEach(item => {
                item.style.display = 'flex';
            });

            // Reset to first amount in carousel
            updateCarouselDisplay(type);
            
            // Reset message text for tips
            if (type === 'tip') {
                messageText.value = updateTipMessage(parseFloat(carouselState[type].items[carouselState[type].currentIndex].dataset.baseAmount));
            }
        }
    };

    // Update carousel with username if applicable
    updateCarouselDisplay(type);
    
    // Initialize conversion rate display with first carousel amount
    const selectedMethod = modal.getAttribute('data-selected-payment') || 'doge';
    const initialAmount = carouselState[type].items[0].getAttribute('data-base-amount');
    updateCustomAmountConversion(initialAmount, selectedMethod, modal);

    // Add class to body to prevent background scroll while keeping position
    document.body.style.top = `-${lastScrollPosition}px`;
    document.body.classList.add('likeme-modal-open');
    
    // Show the modal
    modal.classList.add('show-modal');
}

// Close modal with cleanup
function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (!modal) return;

    // Remove modal open class and restore scroll position
    document.body.classList.remove('likeme-modal-open');
    const scrollY = document.body.style.top;
    document.body.style.top = '';
    window.scrollTo(0, parseInt(scrollY || '0') * -1);

    // Hide the modal
    modal.classList.remove('show-modal');

    // Reset carousel state
    const type = modalId.replace('Modal', '');
    if (carouselState[type]) {
        carouselState[type].currentIndex = 0;
    }
}

// Handle heart click with immediate state reset
function handleHeartClick() {
    if (!heartState.currentTarget) {
        console.log('%cLikeMe: handleHeartClick - No current target', 'color: #FF0000;');
        return;
    }

    console.log('%cLikeMe: handleHeartClick - Starting heart click process', 'color: #ff4d7c;');
    console.log('Current target:', heartState.currentTarget);

    const url = heartState.currentTarget.href || window.location.href;
    console.log('URL:', url);
    
    const username = getPostUsername(heartState.currentTarget);
    console.log('%cLikeMe: handleHeartClick - Extracted username:', username, 'color: #ff4d7c;');
    
    // Store the entire tweet container and its parent context
    const tweetContext = {
        element: findTweetElement(heartState.currentTarget),
        url: url,
        username: username
    };
    
    console.log('Tweet context:', tweetContext);
    
    // Immediately clear all timeouts and states
    clearAllTimeouts();
    resetFlowState();
    
    // Set new flow state with more context
    flowState = {
        isActive: true,
        originalTarget: tweetContext.element || heartState.currentTarget,
        originalUsername: username,
        tweetContext: tweetContext,
        actions: {
            lock: null,
            tip: null
        }
    };
    
    console.log('%cLikeMe: handleHeartClick - Flow state set:', flowState, 'color: #ff4d7c;');
    
    navigator.clipboard.writeText(url).then(() => {
        console.log('%cLikeMe: handleHeartClick - URL copied to clipboard, showing toast', 'color: #ff4d7c;');
        showActionChoiceToast(username, true);
    }).catch(error => {
        console.error('%cLikeMe: handleHeartClick - Failed to copy URL:', error, 'color: #FF0000;');
        // Still show the toast even if clipboard fails
        showActionChoiceToast(username, true);
    });
}

// Helper function to clear all timeouts
function clearAllTimeouts() {
    if (toastTimeout) {
        clearTimeout(toastTimeout);
        toastTimeout = null;
    }
    if (toastInteractionTimeout) {
        clearTimeout(toastInteractionTimeout);
        toastInteractionTimeout = null;
    }
    if (activeToast) {
        activeToast.remove();
        activeToast = null;
    }
}

// Helper function to reset flow state
function resetFlowState() {
    flowState = {
        isActive: false,
        originalTarget: null,
        originalUsername: null,
        actions: {
            lock: null,
            tip: null
        }
    };
    heartState.isLocked = false;
}

// Helper function to remove toast and reset state
function removeToastAndResetState() {
    if (activeToast) {
        activeToast.classList.remove('show');
        // Immediately reset states
        clearAllTimeouts();
        resetFlowState();
        // Remove toast after animation
        setTimeout(() => {
            if (activeToast) {
                activeToast.remove();
                activeToast = null;
            }
        }, 300);
    }
}

// Update showActionChoiceToast function to accept action type
function showActionChoiceToast(username = null, isNewShare = false, action = 'shared') {
    console.log('%cLikeMe: showActionChoiceToast - Starting toast creation', 'color: #ff4d7c;');
    console.log('Input username:', username);
    console.log('Is new share:', isNewShare);
    console.log('Action:', action);
    
    // Clear any existing timeouts first
    clearAllTimeouts();

    const toast = document.createElement('div');
    toast.className = 'likeme-toast show';
    activeToast = toast;
    
    // For new shares, reset the actions and use the provided username
    if (isNewShare) {
        flowState.actions = {
            lock: null,
            tip: null
        };
    }
    
    const displayUsername = isNewShare ? username : 
        (flowState.isActive && username === flowState.originalUsername) ? 
            flowState.originalUsername : username;
    
    console.log('%cLikeMe: showActionChoiceToast - Display username:', displayUsername, 'color: #ff4d7c;');
    console.log('Flow state original username:', flowState.originalUsername);
    
    // Get both amounts if they exist
    const lockAmount = flowState.actions.lock;
    const tipAmount = flowState.actions.tip;

    // Determine message based on action
    let actionMessage = 'Shared';
    let extraLink = '';
    if (action === 'locked') {
        actionMessage = 'Locked';
    } else if (action === 'tipped') {
        actionMessage = 'Sent';
    } else if (action === 'shared') {
        // Only for shared, add the link as a block below
        extraLink = `<div style=\"margin-top:2px;font-size:13px;\"><a href=\"https://hodlocker.com\" target=\"_blank\" rel=\"noopener noreferrer\" style=\"color:#ff4d7c;text-decoration:underline;font-weight:500;display:inline-block;\">hodlocker.com</a></div>`;
    }
    
    console.log('%cLikeMe: showActionChoiceToast - Creating toast with username:', displayUsername, 'color: #ff4d7c;');
    
    toast.innerHTML = `
        <div class=\"likeme-toast-header\">
            <div class=\"likeme-toast-message\">
                <div style=\"display:flex;align-items:center;gap:8px;\">
                    <span class=\"likeme-toast-check\">✓</span>
                    <span style=\"font-weight:700;\">${actionMessage}</span>
                </div>
                ${extraLink}
            </div>
            <button type=\"button\" class=\"likeme-toast-close\" aria-label=\"Close\">
                <svg viewBox=\"0 0 24 24\" width=\"20\" height=\"20\">
                    <path fill=\"currentColor\" d=\"M10.59 12L4.54 5.96l1.42-1.42L12 10.59l6.04-6.05 1.42 1.42L13.41 12l6.05 6.04-1.42 1.42L12 13.41l-6.04 6.05-1.42-1.42L10.59 12z\"/>
                </svg>
            </button>
        </div>
        <div class=\"likeme-toast-actions\">
            <div class=\"likeme-toast-action-group\">
                <button type=\"button\" class=\"likeme-toast-button likeme-lock-button\">
                    <div class=\"likeme-button-content\">
                        <span class=\"likeme-button-icon\">
                            <svg viewBox=\"0 0 24 24\" width=\"18\" height=\"18\">
                                <path fill=\"currentColor\" d=\"M12 1.75c-3.31 0-6 2.69-6 6v2.75c-.95.31-1.75 1.04-1.75 2.25v8.5c0 1.38 1.12 2.5 2.5 2.5h10.5c1.38 0 2.5-1.12 2.5-2.5v-8.5c0-1.21-.8-1.94-1.75-2.25V7.75c0-3.31-2.69-6-6-6zm-4.25 6c0-2.34 1.91-4.25 4.25-4.25s4.25 1.91 4.25 4.25v2.5h-8.5V7.75z\"/>
                            </svg>
                        </span>
                        <span class=\"likeme-button-label\">Lock</span>
                    </div>
                </button>
                <div class=\"likeme-button-amount-below\">${lockAmount && lockAmount.amount ? formatCryptoAmountDisplay(lockAmount.amount) : ''}</div>
            </div>
            <div class=\"likeme-toast-action-group\">
                <button type=\"button\" class=\"likeme-toast-button likeme-tip-button\">
                    <div class=\"likeme-button-content\">
                        <span class=\"likeme-button-icon\">$</span>
                        <span class=\"likeme-button-label\">${displayUsername ? `@${displayUsername}` : 'Tip'}</span>
                    </div>
                </button>
                <div class=\"likeme-button-amount-below\">${tipAmount && tipAmount.amount ? formatCryptoAmountDisplay(tipAmount.amount) : ''}</div>
            </div>
        </div>
    `;

    // Add style for the pink tick and remove ::before if present
    style.textContent += `
        .likeme-toast-check {
            color: rgb(255, 77, 124);
            font-size: 18px;
            font-weight: bold;
            margin-right: 8px;
            vertical-align: middle;
        }
    `;
    // Remove .likeme-toast-message::before if present (handled by HTML now)
    style.textContent = style.textContent.replace(/\.likeme-toast-message::before[\s\S]*?\}/g, '');

    document.head.appendChild(style);

    document.body.appendChild(toast);

    // Ensure hodlocker.com link is clickable by stopping propagation
    const hodlockerLink = toast.querySelector('.likeme-toast-message a');
    if (hodlockerLink) {
        hodlockerLink.addEventListener('click', (e) => {
            e.stopPropagation();
        });
    }

    const lockButton = toast.querySelector('.likeme-lock-button');
    const tipButton = toast.querySelector('.likeme-tip-button');
    const closeButton = toast.querySelector('.likeme-toast-close');

    const handleButtonClick = (e, type) => {
        e.preventDefault();
        e.stopPropagation();
        lastScrollPosition = window.scrollY;
        clearAllTimeouts();
        showModal(type, displayUsername);
        requestAnimationFrame(() => {
            window.scrollTo(0, lastScrollPosition);
        });
    };

    lockButton.addEventListener('click', (e) => handleButtonClick(e, 'lock'));
    tipButton.addEventListener('click', (e) => handleButtonClick(e, 'tip'));
    
    closeButton.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        heartState.isLocked = false;
        removeToastAndResetState();
    });

    toast.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
    });

    toastTimeout = setTimeout(() => {
        heartState.isLocked = false;
        removeToastAndResetState();
    }, 20000);
}

// Function to post reply directly on Twitter
async function postTwitterReply(tweetElement, replyText) {
    console.log('%cLikeMe: Starting reply process', 'color: #ff4d7c; font-weight: bold;');
    console.log('Tweet element:', tweetElement);
    console.log('Reply text:', replyText);

    if (!tweetElement) {
        console.error('%cLikeMe: No tweet element provided', 'color: red;');
        return;
    }

    try {
        // First try to find the reply button in the tweet's action bar
        const actionBar = tweetElement.querySelector('[role="group"]');
        console.log('Action bar found:', actionBar);

        // Try multiple methods to find the reply button
        let replyButton = null;

        // Method 1: Direct data-testid
        replyButton = actionBar?.querySelector('[data-testid="reply"]');
        console.log('Method 1 - Direct data-testid:', replyButton);

        // Method 2: Aria label
        if (!replyButton) {
            replyButton = actionBar?.querySelector('[aria-label*="Reply"], [aria-label*="reply"]');
            console.log('Method 2 - Aria label:', replyButton);
        }

        // Method 3: Role button with reply-related attributes
        if (!replyButton) {
            const buttons = Array.from(actionBar?.querySelectorAll('div[role="button"]') || []);
            replyButton = buttons.find(button => {
                const ariaLabel = button.getAttribute('aria-label')?.toLowerCase() || '';
                const text = button.textContent?.toLowerCase() || '';
                return ariaLabel.includes('reply') || text.includes('reply');
            });
            console.log('Method 3 - Role button search:', replyButton);
        }

        if (!replyButton) {
            console.error('%cLikeMe: Reply button not found', 'color: red;');
            return;
        }

        // Click the reply button
        console.log('Clicking reply button...');
        replyButton.click();

        // Wait for the reply dialog
        console.log('Waiting for reply dialog...');
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Try to find the reply input with multiple attempts
        let replyInput = null;
        let attempts = 0;
        const maxAttempts = 5;

        while (!replyInput && attempts < maxAttempts) {
            // Try multiple selectors for the reply input
            const selectors = [
                '[data-testid="tweetTextarea_0"]',
                '[data-testid="tweetTextarea_1"]',
                '[contenteditable="true"]',
                '[aria-label*="Tweet text"]',
                '[aria-label*="Post text"]',
                'div[role="textbox"]'
            ];

            for (const selector of selectors) {
                replyInput = document.querySelector(selector);
                if (replyInput) break;
            }

            if (!replyInput) {
                console.log(`Attempt ${attempts + 1}: Reply input not found, waiting...`);
                await new Promise(resolve => setTimeout(resolve, 500));
                attempts++;
            }
        }

        if (!replyInput) {
            console.error('%cLikeMe: Reply input not found after multiple attempts', 'color: red;');
            return;
        }

        console.log('Reply input found:', replyInput);

        // Focus the input first
        replyInput.focus();
        
        // Use execCommand to insert text (more compatible with React)
        document.execCommand('selectAll', false, null);
        document.execCommand('insertText', false, replyText);

        // Backup method: directly set properties
        if (!replyInput.textContent || replyInput.textContent !== replyText) {
            replyInput.textContent = replyText;
            // Create and dispatch a more basic input event
            const event = new Event('input', {
                bubbles: true,
                cancelable: true,
            });
            replyInput.dispatchEvent(event);
        }

        // Wait for Twitter to process the input
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Find the submit button with multiple methods
        let submitButton = null;
        attempts = 0;

        while (!submitButton && attempts < maxAttempts) {
            // Try multiple selectors for the submit button
            const selectors = [
                '[data-testid="tweetButton"]',
                '[data-testid="postButton"]',
                'div[role="button"][aria-label*="Reply"]',
                'div[role="button"][aria-label*="Tweet"]'
            ];

            for (const selector of selectors) {
                submitButton = document.querySelector(selector);
                if (submitButton) break;
            }

            if (!submitButton) {
                // Try finding by role and text content
                const buttons = Array.from(document.querySelectorAll('div[role="button"]'));
                submitButton = buttons.find(button => {
                    const text = button.textContent?.toLowerCase() || '';
                    const ariaLabel = button.getAttribute('aria-label')?.toLowerCase() || '';
                    return (text.includes('reply') || text.includes('tweet')) && 
                           !button.disabled && 
                           button.style.opacity !== '0.5';
                });
            }

            if (!submitButton) {
                console.log(`Attempt ${attempts + 1}: Submit button not found, waiting...`);
                await new Promise(resolve => setTimeout(resolve, 500));
                attempts++;
            }
        }

        if (submitButton && !submitButton.disabled) {
            // Wait a bit more to ensure the button is truly ready
            await new Promise(resolve => setTimeout(resolve, 500));
            console.log('Clicking submit button...');
            submitButton.click();
            console.log('%cLikeMe: Reply posted successfully!', 'color: #00BA7C; font-weight: bold;');
        } else {
            console.error('%cLikeMe: Submit button not found or disabled', 'color: red;');
        }
    } catch (error) {
        console.error('%cLikeMe: Error posting reply:', 'color: red;', error);
    }
}

function findTweetElement(target) {
    console.log('%cLikeMe: Finding tweet element', 'color: #ff4d7c;');
    console.log('Starting from target:', target);
    
    if (!target) {
        console.error('No target provided');
        return null;
    }

    // First try to find the direct tweet container
    const selectors = [
        'article[data-testid="tweet"]',
        'article[role="article"]',
        'div[data-testid="tweet"]',
        'div[data-testid="tweetDetail"]',
        '[data-testid="cellInnerDiv"] article',
        '[data-testid="cellInnerDiv"] div[data-testid="tweet"]'
    ];

    // Try each selector
    let tweetElement = null;
    for (const selector of selectors) {
        // Try both closest and querySelector to handle both parent and child cases
        tweetElement = target.closest(selector) || target.querySelector(selector);
        if (tweetElement) {
            console.log(`Found tweet element using selector: ${selector}`);
            break;
        }
    }

    // If not found, try traversing up through parents
    if (!tweetElement) {
        console.log('Tweet not found with direct selectors, trying parent traversal...');
        let current = target;
        while (current && current !== document.body) {
            // Check if this element is a tweet
            if (current.tagName.toLowerCase() === 'article' || 
                current.getAttribute('data-testid') === 'tweet' ||
                current.getAttribute('role') === 'article') {
                tweetElement = current;
                console.log('Found tweet element through parent traversal');
                break;
            }
            // Try to find tweet within this element
            const found = current.querySelector('article[data-testid="tweet"], div[data-testid="tweet"]');
            if (found) {
                tweetElement = found;
                console.log('Found tweet element within parent');
                break;
            }
            current = current.parentElement;
        }
    }

    // If still not found, try looking for specific tweet elements
    if (!tweetElement) {
        console.log('Trying to find tweet by specific elements...');
        // Look for elements that are typically only in tweets
        const tweetSpecificElement = target.closest('div:has([data-testid="reply"], [data-testid="like"], [data-testid="retweet"])') ||
                                   target.closest('div:has([aria-label*="Reply"], [aria-label*="Like"], [aria-label*="Retweet"])');
        
        if (tweetSpecificElement) {
            tweetElement = tweetSpecificElement.closest('article') || tweetSpecificElement;
            console.log('Found tweet element through specific tweet elements');
        }
    }

    console.log('Final tweet element found:', tweetElement);
    
    // Validate that we found a proper tweet element
    if (tweetElement) {
        const hasActions = tweetElement.querySelector('[role="group"], [data-testid="reply"], [aria-label*="Reply"]');
        if (!hasActions) {
            console.log('Found element does not contain tweet actions, might not be a valid tweet');
            return null;
        }
    }

    return tweetElement;
}

function confirmLock() {
    if (!flowState.isActive) return;
    
    const modal = document.getElementById('lockModal');
    const customAmount = document.getElementById('lockCustomAmount').value;
    const selectedMethod = modal.getAttribute('data-selected-payment');
    const symbol = getPaymentMethodSymbol(selectedMethod);
    const { rate, name } = getPaymentMethodInfo(selectedMethod);
    const cryptoInput = modal.querySelector('.likeme-conversion-input');
    
    let amount, formattedAmount;
    if (cryptoInput && cryptoInput.value && !isNaN(cryptoInput.value) && Number(cryptoInput.value) > 0) {
        // User edited the crypto field
        amount = parseFloat(cryptoInput.value);
        formattedAmount = `${symbol}${amount} ${name}`;
    } else if (customAmount) {
        // User edited the USD field
        amount = (parseFloat(customAmount) * rate).toFixed(getDecimals(selectedMethod));
        formattedAmount = `${symbol}${amount} ${name}`;
    } else {
        const activeItem = modal.querySelector('.likeme-amount-item.active');
        const baseAmount = activeItem.getAttribute('data-base-amount');
        amount = (parseFloat(baseAmount) * rate).toFixed(getDecimals(selectedMethod));
        formattedAmount = `${symbol}${amount} ${name}`;
    }
    
    // Update the flow state with payment method info
    flowState.actions.lock = {
        amount: formattedAmount,
        method: selectedMethod
    };
    
    closeModal('lockModal');
    clearAllTimeouts();
    
    showActionChoiceToast(flowState.originalUsername, false, 'locked');

    // Handle comment posting if enabled
    const shouldPostComment = document.getElementById('lockMessageCheckbox').checked;
    const commentText = document.getElementById('lockMessageText').value;
    
    if (shouldPostComment && flowState.originalTarget) {
        const tweetElement = findTweetElement(flowState.originalTarget);
        if (tweetElement) {
            postTwitterReply(tweetElement, commentText);
        }
    }
}

function confirmTip() {
    if (!flowState.isActive) return;
    
    const modal = document.getElementById('tipModal');
    const customAmount = document.getElementById('tipCustomAmount').value;
    const selectedMethod = modal.getAttribute('data-selected-payment');
    const symbol = getPaymentMethodSymbol(selectedMethod);
    const { rate, name } = getPaymentMethodInfo(selectedMethod);
    const cryptoInput = modal.querySelector('.likeme-conversion-input');
    
    let amount, formattedAmount;
    if (cryptoInput && cryptoInput.value && !isNaN(cryptoInput.value) && Number(cryptoInput.value) > 0) {
        // User edited the crypto field
        amount = parseFloat(cryptoInput.value);
        formattedAmount = `${symbol}${amount} ${name}`;
    } else if (customAmount) {
        // User edited the USD field
        amount = (parseFloat(customAmount) * rate).toFixed(getDecimals(selectedMethod));
        formattedAmount = `${symbol}${amount} ${name}`;
    } else {
        const activeItem = modal.querySelector('.likeme-amount-item.active');
        const baseAmount = activeItem.getAttribute('data-base-amount');
        amount = (parseFloat(baseAmount) * rate).toFixed(getDecimals(selectedMethod));
        formattedAmount = `${symbol}${amount} ${name}`;
    }
    
    // Update the flow state with payment method info
    flowState.actions.tip = {
        amount: formattedAmount,
        method: selectedMethod
    };
    
    closeModal('tipModal');
    clearAllTimeouts();
    
    showActionChoiceToast(flowState.originalUsername, false, 'tipped');

    // Handle comment posting if enabled
    const shouldPostComment = document.getElementById('tipMessageCheckbox').checked;
    const commentText = document.getElementById('tipMessageText').value;
    
    if (shouldPostComment && flowState.originalTarget) {
        const tweetElement = findTweetElement(flowState.originalTarget);
        if (tweetElement) {
            postTwitterReply(tweetElement, commentText);
        }
    }
}

// Check if element matches conditions
function matchesConditions(element, conditions) {
    if (!conditions) return true;

    for (const [condition, value] of Object.entries(conditions)) {
        switch (condition) {
            case 'textStartsWith':
                if (!element.textContent?.trim().startsWith(value)) return false;
                break;
            case 'hasSelector':
                if (!element.querySelector(value)) return false;
                break;
            case 'urlIncludes':
                const href = element.href || '';
                if (!value.some(include => href.includes(include))) return false;
                break;
            case 'urlExcludes':
                const url = element.href || '';
                if (value.some(exclude => url.includes(exclude))) return false;
                break;
            case 'urlMatches':
                const elementUrl = element.href || '';
                const urlPath = elementUrl.split('?')[0].split('#')[0].replace(window.location.origin, '');
                if (!new RegExp(value).test(urlPath)) return false;
                break;
        }
    }
    return true;
}

// Find shareable elements based on platform configuration
function findShareableElements() {
    const platform = getCurrentPlatform();
    console.log('LikeMe: Current platform:', platform);
    
    const config = platformConfig[platform];
    if (!config?.enabled) {
        console.log('LikeMe: Platform not enabled or config not found');
        return [];
    }

    let elements = [];
    
    Object.entries(config.elements).forEach(([elementType, elementConfig]) => {
        if (!elementConfig.enabled) return;

        elementConfig.selectors.forEach(selector => {
            try {
                const found = Array.from(document.querySelectorAll(selector));
                console.log(`LikeMe: Found ${found.length} elements for selector "${selector}"`);
                
                const filtered = found.filter(el => matchesConditions(el, elementConfig.conditions));
                console.log(`LikeMe: ${filtered.length} elements passed conditions for "${elementType}"`);
                
                elements.push(...filtered);
            } catch (error) {
                console.error(`LikeMe: Error with selector "${selector}":`, error);
            }
        });
    });

    // Filter out hidden elements and duplicates
    const visible = Array.from(new Set(elements)).filter(el => {
        const rect = el.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0;
    });

    console.log(`LikeMe: Found ${visible.length} visible elements total`);
    return visible;
}

// Get element description from configuration
function getElementDescription(element) {
    const platform = getCurrentPlatform();
    const config = platformConfig[platform];
    if (!config?.enabled) return { type: '🔗 Link', detail: 'Shareable content' };

    for (const [elementType, elementConfig] of Object.entries(config.elements)) {
        if (!elementConfig.enabled) continue;

        const matches = elementConfig.selectors.some(selector => 
            element.matches(selector) && matchesConditions(element, elementConfig.conditions)
        );

        if (matches) {
            return {
                type: `${elementConfig.icon} ${elementConfig.type}`,
                detail: getElementDetail(element, elementConfig)
            };
        }
    }

    return { type: '🔗 Link', detail: getElementDetail(element) };
}

// Get element detail text
function getElementDetail(element, config = null) {
    const text = element.textContent?.trim() || '';
    const detail = text.length > 50 ? text.substring(0, 47) + '...' : text;
    
    if (config?.type.includes('Share')) {
        return `Share on ${getCurrentPlatform()}`;
    }
    
    return detail || element.href || 'Shareable content';
}

// Update heart position tracking to be independent of flow state
function updateHeartPosition(mouseX, mouseY) {
    if (!isEnabled || !heart) return;
    if (heart.style.display === 'none') return;
    if (heartState.isLocked) return;

    const platform = getCurrentPlatform();
    if (!platform) return;

    const config = platformConfig[platform];
    if (!config?.enabled) return;

    // Find all visible posts
    const posts = Array.from(document.querySelectorAll(config.selectors.post))
        .filter(post => {
            const rect = post.getBoundingClientRect();
            // Consider post visible if any part is in the viewport
            return rect.height > 0 && rect.bottom > 0 && rect.top < window.innerHeight;
        });

    // Find the post that contains the mouse position vertically
    let targetPost = null;
    let closestDistance = Infinity;
    
    for (const post of posts) {
        const rect = post.getBoundingClientRect();
        if (mouseY >= rect.top && mouseY <= rect.bottom) {
            targetPost = post;
            break;
        }
        
        // If mouse is not inside any post, find the closest one
        const distance = Math.min(
            Math.abs(mouseY - rect.top),
            Math.abs(mouseY - rect.bottom)
        );
        if (distance < closestDistance) {
            closestDistance = distance;
            targetPost = post;
        }
    }

    if (targetPost) {
        const rect = targetPost.getBoundingClientRect();
        
        // Always position at the right edge and center vertically
        const finalX = rect.right - heart.offsetWidth;
        const finalY = rect.top + (rect.height / 2) - (heart.offsetHeight / 2);

        // Apply position with smooth transition
        heart.style.transition = 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)';
        heart.style.left = `${finalX}px`;
        heart.style.top = `${finalY}px`;
        heart.classList.add('active');
        heart.style.display = '';
        
        heartState.currentTarget = targetPost;
    } else {
        heart.classList.remove('active');
        heartState.currentTarget = null;
    }
}

// Get username from post
function getPostUsername(post) {
    if (!post) {
        console.log('%cLikeMe: getPostUsername - No post provided', 'color: #ff4d7c;');
        return null;
    }
    
    console.log('%cLikeMe: getPostUsername - Starting extraction', 'color: #ff4d7c;');
    console.log('Post element:', post);
    
    let username = null;
    
    // Method 1: Primary selector - Twitter's standard structure
    const primarySelectors = [
        'div[data-testid="User-Name"] a[href^="/"]',
        'div[data-testid="User-Name"] a[href^="/@"]',
        'a[href^="/"][role="link"]',
        'a[href^="/@"][role="link"]'
    ];
    
    for (const selector of primarySelectors) {
        const usernameElement = post.querySelector(selector);
        if (usernameElement) {
            const href = usernameElement.getAttribute('href');
            console.log(`%cLikeMe: Found username element with selector: ${selector}`, 'color: #00BA7C;');
            console.log('Href attribute:', href);
            
            // Extract username from href, removing leading / or /@
            username = href.replace(/^\/(@)?/, '').split('/')[0];
            console.log('Extracted username:', username);
            
            if (username && validateUsername(username)) {
                console.log('%cLikeMe: Username extraction successful', 'color: #00BA7C;');
                return username;
            }
        }
    }
    
    // Method 2: Fallback - Look for any link with username pattern
    const fallbackSelectors = [
        'a[href*="/status/"]', // Links to tweets
        'a[href^="/"]', // Any link starting with /
        'a[href^="/@"]' // Any link starting with /@
    ];
    
    for (const selector of fallbackSelectors) {
        const links = post.querySelectorAll(selector);
        for (const link of links) {
            const href = link.getAttribute('href');
            if (href && href.includes('/')) {
                // Extract potential username from path
                const pathParts = href.split('/').filter(part => part.length > 0);
                if (pathParts.length > 0) {
                    const potentialUsername = pathParts[0].replace(/^@/, '');
                    console.log(`%cLikeMe: Fallback - Found potential username: ${potentialUsername}`, 'color: #FFA500;');
                    
                    if (validateUsername(potentialUsername)) {
                        console.log('%cLikeMe: Fallback username validation successful', 'color: #00BA7C;');
                        return potentialUsername;
                    }
                }
            }
        }
    }
    
    // Method 3: Text content fallback - Look for @username in text
    const textContent = post.textContent || '';
    const usernameMatch = textContent.match(/@([a-zA-Z0-9_]{1,15})/);
    if (usernameMatch) {
        const textUsername = usernameMatch[1];
        console.log(`%cLikeMe: Text content fallback - Found username: ${textUsername}`, 'color: #FFA500;');
        
        if (validateUsername(textUsername)) {
            console.log('%cLikeMe: Text content username validation successful', 'color: #00BA7C;');
            return textUsername;
        }
    }
    
    // Method 4: Data attributes fallback
    const dataUsername = post.getAttribute('data-username') || 
                        post.querySelector('[data-username]')?.getAttribute('data-username');
    if (dataUsername) {
        console.log(`%cLikeMe: Data attribute fallback - Found username: ${dataUsername}`, 'color: #FFA500;');
        
        if (validateUsername(dataUsername)) {
            console.log('%cLikeMe: Data attribute username validation successful', 'color: #00BA7C;');
            return dataUsername;
        }
    }
    
    console.log('%cLikeMe: Username extraction failed - no valid username found', 'color: #FF0000;');
    return null;
}

// Username validation function
function validateUsername(username) {
    if (!username || typeof username !== 'string') {
        console.log('%cLikeMe: Username validation failed - invalid type or empty', 'color: #FF0000;');
        return false;
    }
    
    // Remove any @ symbol if present
    const cleanUsername = username.replace(/^@/, '');
    
    // Twitter username rules:
    // - 1-15 characters long
    // - Only alphanumeric characters and underscores
    // - Cannot start with a number
    // - Cannot be only numbers
    const usernameRegex = /^[a-zA-Z][a-zA-Z0-9_]{0,14}$/;
    const isValid = usernameRegex.test(cleanUsername);
    
    console.log(`%cLikeMe: Username validation - "${cleanUsername}" is ${isValid ? 'valid' : 'invalid'}`, 
                isValid ? 'color: #00BA7C;' : 'color: #FF0000;');
    
    return isValid;
}

// Update showToast to handle different types
function showToast(message, showActions = true, username = null) {
    if (showActions) {
        showActionChoiceToast(username);
        return;
    }

    // For simple notifications
    const toast = document.createElement('div');
    toast.className = 'likeme-toast show';
    toast.innerHTML = `
        <div class="likeme-toast-message">
            ${message}
        </div>
    `;
    document.body.appendChild(toast);

    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 3000);
}

// Create toggle button
function createToggleButton() {
    console.log('LikeMe: Creating toggle button...');
    if (toggleButton) {
        console.log('LikeMe: Toggle button already exists');
        return;
    }
    
    toggleButton = document.createElement('div');
    toggleButton.className = 'likeme-toggle' + (isEnabled ? '' : ' disabled');
    toggleButton.innerHTML = `
        <div class="tooltip">Toggle LikeMe ${isEnabled ? 'Off' : 'On'}</div>
        <svg viewBox="0 0 24 24">
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
        </svg>
    `;

    document.body.appendChild(toggleButton);

    toggleButton.addEventListener('click', () => {
        isEnabled = !isEnabled;
        console.log('LikeMe: Toggle clicked, new state:', isEnabled ? 'enabled' : 'disabled');
        toggleButton.className = 'likeme-toggle' + (isEnabled ? '' : ' disabled');
        toggleButton.querySelector('.tooltip').textContent = `Toggle LikeMe ${isEnabled ? 'Off' : 'On'}`;
        
        // Save state
        chrome.storage.local.set({ likemeEnabled: isEnabled });

        if (isEnabled) {
            if (!heart) {
                createHeart();
                createModals();
            } else {
                heart.style.display = '';
                heart.classList.remove('disabled');
            }
        } else {
            if (heart) {
                // Hide the heart immediately
                heart.style.display = 'none';
                heart.classList.add('disabled');
                // Reset heart state
                heartState.isLocked = false;
                heartState.currentTarget = null;
            }
            // Remove any active toasts
            if (activeToast) {
                activeToast.remove();
                activeToast = null;
            }
            // Clear any pending timeouts
            if (toastTimeout) {
                clearTimeout(toastTimeout);
                toastTimeout = null;
            }
            if (toastInteractionTimeout) {
                clearTimeout(toastInteractionTimeout);
                toastInteractionTimeout = null;
            }
            if (moveTimeout) {
                clearTimeout(moveTimeout);
                moveTimeout = null;
            }
            // Reset flow state
            resetFlowState();
        }
    });

    console.log('LikeMe: Toggle button created and added to page');
}

// Simplified scroll observer
function setupScrollObserver() {
    const platform = getCurrentPlatform();
    if (!platform) return;

    const config = platformConfig[platform];
    if (!config?.enabled) return;

    const observer = new MutationObserver(() => {
        if (currentTarget && currentTarget.isConnected) {
            const rect = currentTarget.getBoundingClientRect();
            if (heart) {
                heart.style.transition = 'none';
                heart.style.left = `${rect.right - heart.offsetWidth}px`;
                heart.style.top = `${rect.top + (rect.height / 2) - (heart.offsetHeight / 2)}px`;
            }
        } else {
            heart.classList.remove('active');
            currentTarget = null;
        }
    });

    const timeline = document.querySelector('div[data-testid="primaryColumn"]');
    if (timeline) {
        observer.observe(timeline, { 
            childList: true, 
            subtree: true,
            characterData: true,
            attributes: true 
        });
    }
}

// Simplified resize observer
function setupResizeObserver() {
    if (!heart) return;

    const resizeObserver = new ResizeObserver(() => {
        const platform = getCurrentPlatform();
        if (!platform) return;

        const config = platformConfig[platform];
        if (!config?.enabled || !currentTarget?.isConnected) return;

        const rect = currentTarget.getBoundingClientRect();
        heart.style.transition = 'none';
        heart.style.left = `${rect.right - heart.offsetWidth}px`;
        heart.style.top = `${rect.top + (rect.height / 2) - (heart.offsetHeight / 2)}px`;
    });

    resizeObserver.observe(document.body);
}

// Add mousemove listener
document.addEventListener('mousemove', (e) => {
    if (!isEnabled || !heart || heartState.isLocked) return;
    lastMousePosition.x = e.clientX;
    lastMousePosition.y = e.clientY;
    updateHeartPosition(e.clientX, e.clientY);
}, {passive: true});

// Start the extension
console.log('LikeMe: Content script starting...');
loadPlatformConfig();

// Listen for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('LikeMe: Received message:', message);
    if (message.action === 'enable') {
        isEnabled = true;
        if (toggleButton) {
            toggleButton.className = 'likeme-toggle';
            toggleButton.querySelector('.tooltip').textContent = 'Toggle LikeMe Off';
        }
        if (heart) {
            heart.style.display = '';
            heart.classList.remove('disabled');
        } else {
            initializeExtension();
        }
    } else if (message.action === 'disable') {
        isEnabled = false;
        if (toggleButton) {
            toggleButton.className = 'likeme-toggle disabled';
            toggleButton.querySelector('.tooltip').textContent = 'Toggle LikeMe On';
        }
        if (heart) {
            heart.style.display = 'none';
            heart.classList.add('disabled');
            // Reset heart state
            heartState.isLocked = false;
            heartState.currentTarget = null;
            // Remove any active toasts
            if (activeToast) {
                activeToast.remove();
                activeToast = null;
            }
            // Clear any pending timeouts
            if (toastTimeout) {
                clearTimeout(toastTimeout);
                toastTimeout = null;
            }
            if (toastInteractionTimeout) {
                clearTimeout(toastInteractionTimeout);
                toastInteractionTimeout = null;
            }
            if (moveTimeout) {
                clearTimeout(moveTimeout);
                moveTimeout = null;
            }
            // Reset flow state
            resetFlowState();
        }
    }
});

// Add styles for modal scroll handling and X-style design
const style = document.createElement('style');
style.textContent += `
    body.likeme-modal-open {
        position: fixed;
        width: 100%;
        overflow-y: scroll;
    }

    .likeme-modal {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(91, 112, 131, 0.4);
        display: none;
        justify-content: center;
        align-items: center;
        z-index: 10000;
        overflow-y: auto;
        padding: 20px;
        box-sizing: border-box;
        backdrop-filter: blur(5px);
    }

    .likeme-modal-content {
        background: rgb(0, 0, 0);
        border-radius: 16px;
        padding: 32px;
        position: relative;
        width: 100%;
        max-width: 600px;
        margin: auto;
        box-shadow: rgb(255 255 255 / 20%) 0px 0px 15px, rgb(255 255 255 / 15%) 0px 0px 3px 1px;
        color: rgb(247, 249, 249);
        border: 1px solid rgb(47, 51, 54);
        box-sizing: border-box;
    }

    .likeme-modal * {
        box-sizing: border-box;
    }

    .amount-highlight {
        color: rgb(255, 77, 124);
        transition: color 0.2s ease;
        font-weight: 700;
    }

    .likeme-modal.show-modal {
        display: flex;
    }

    .likeme-modal-header {
        margin-bottom: 24px;
    }

    .likeme-brand {
        color: rgb(247, 249, 249);
        font-size: 20px;
        font-weight: 700;
        margin-bottom: 8px;
        letter-spacing: -0.5px;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .likeme-disclaimer {
        color: rgb(113, 118, 123);
        font-size: 12px;
        text-align: center;
        line-height: 1.4;
        margin-top: 8px;
        font-weight: 400;
    }

    .likeme-brand-heart {
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .likeme-brand-heart svg {
        width: 20px;
        height: 20px;
        fill: rgb(255, 77, 124);
        transition: fill 0.3s ease;
    }

    .likeme-brand:hover .likeme-brand-heart {
        transform: scale(1.1);
    }

    .likeme-brand:hover .likeme-brand-heart svg {
        fill: rgb(255, 31, 90);
    }

    .likeme-modal-title {
        font-size: 18px;
        font-weight: 700;
        display: flex;
        align-items: center;
        gap: 12px;
        color: rgb(247, 249, 249);
    }

    .likeme-modal-title svg {
        stroke: rgb(247, 249, 249);
    }

    .likeme-amount-carousel {
        height: 200px;
        transition: visibility 0.3s ease, opacity 0.3s ease;
        margin: 20px 0;
        background: rgb(0, 0, 0);
    }

    .likeme-amount-item {
        color: rgb(247, 249, 249);
        font-size: 20px;
        font-weight: 700;
        padding: 12px;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.2s ease;
    }

    .likeme-amount-item:hover {
        background: rgba(239, 243, 244, 0.1);
    }

    .likeme-amount-item.active {
        color: rgb(255, 77, 124);
    }

    .likeme-custom-amount {
        margin: 20px 0;
    }

    .likeme-custom-amount-label {
        color: rgb(247, 249, 249);
        font-size: 15px;
        margin-bottom: 8px;
        display: block;
        font-weight: 400;
    }

    .likeme-custom-amount-input {
        width: 100%;
        padding: 12px;
        border: 1px solid rgb(47, 51, 54);
        border-radius: 4px;
        background: rgb(0, 0, 0);
        color: rgb(247, 249, 249);
        font-size: 15px;
        transition: all 0.2s ease;
    }

    .likeme-custom-amount-input:focus {
        border-color: rgb(255, 77, 124);
        box-shadow: rgb(255 77 124 / 20%) 0px 0px 0px 1px;
    }

    .likeme-message-section {
        margin-top: 24px;
        border-top: 1px solid rgb(47, 51, 54);
        padding-top: 24px;
    }

    .likeme-message-checkbox {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 15px;
        cursor: pointer;
        user-select: none;
        margin-bottom: 12px;
    }

    .likeme-message-checkbox span {
        color: rgb(247, 249, 249) !important;
        font-weight: 400;
        opacity: 1 !important;
    }

    .likeme-message-checkbox input[type="checkbox"] {
        width: 18px;
        height: 18px;
        margin: 0;
        cursor: pointer;
        border-radius: 4px;
        border: 2px solid rgb(113, 118, 123);
        background: rgb(0, 0, 0);
        appearance: none;
        -webkit-appearance: none;
        position: relative;
        transition: all 0.2s ease;
    }

    .likeme-message-checkbox input[type="checkbox"]:hover {
        border-color: rgb(239, 243, 244);
    }

    .likeme-message-checkbox input[type="checkbox"]:checked {
        background: rgb(255, 77, 124);
        border-color: rgb(255, 77, 124);
    }

    .likeme-message-checkbox input[type="checkbox"]:checked::after {
        content: "✓";
        position: absolute;
        color: rgb(255, 255, 255);
        font-size: 12px;
        left: 3px;
        top: 0px;
    }

    .likeme-message-field {
        margin-top: 12px;
        background: rgb(0, 0, 0);
        border-radius: 8px;
        padding: 2px;
        border: 1px solid rgb(47, 51, 54);
    }

    .likeme-message-input {
        width: 100%;
        min-height: 80px;
        max-height: 80px;
        padding: 12px;
        border: none;
        border-radius: 8px;
        font-size: 15px;
        line-height: 1.5;
        color: rgb(247, 249, 249);
        resize: none;
        background: rgb(0, 0, 0);
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    }

    .likeme-message-input:focus {
        outline: none;
        background: rgb(0, 0, 0);
    }

    .likeme-message-input::placeholder {
        color: rgb(113, 118, 123);
    }

    .likeme-message-field:focus-within {
        border-color: rgb(255, 77, 124);
        box-shadow: rgb(255 77 124 / 20%) 0px 0px 0px 1px;
    }

    .likeme-modal-actions {
        display: flex;
        gap: 12px;
        margin-top: 24px;
    }

    .likeme-modal-button {
        flex: 1;
        padding: 12px 24px;
        border: none;
        border-radius: 9999px;
        cursor: pointer;
        font-size: 15px;
        font-weight: 700;
        transition: background-color 0.2s ease;
        min-height: 44px;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
    }

    .likeme-modal-button.cancel {
        background: transparent;
        border: 1px solid rgb(83, 100, 113);
        color: rgb(247, 249, 249);
    }

    .likeme-modal-button.cancel:hover {
        background: rgba(239, 243, 244, 0.1);
    }

    .likeme-modal-button.confirm {
        background: rgb(255, 77, 124);
        border-color: rgb(255, 77, 124);
    }

    .likeme-modal-button.confirm:hover {
        background: rgb(255, 31, 90);
    }

    .likeme-clear-button {
        position: absolute;
        top: 8px;
        right: 8px;
        width: 24px;
        height: 24px;
        border: none;
        background: rgba(255, 77, 124, 0.1);
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0;
        transition: all 0.2s ease;
        opacity: 0.8;
    }

    .likeme-clear-button:hover {
        background: rgba(255, 77, 124, 0.2);
        opacity: 1;
    }

    .likeme-clear-button svg {
        fill: rgb(255, 77, 124);
    }

    /* Toast Styles */
    .likeme-toast {
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: rgb(0, 0, 0);
        border-radius: 16px;
        padding: 16px;
        box-shadow: rgb(255 255 255 / 20%) 0px 0px 15px, rgb(255 255 255 / 15%) 0px 0px 3px 1px;
        z-index: 10000;
        opacity: 0;
        transition: all 0.2s ease;
        width: 600px;
        border: 1px solid rgb(47, 51, 54);
    }

    .likeme-toast.show {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
    }

    .likeme-toast-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 16px;
    }

    .likeme-toast-message {
        display: flex;
        align-items: center;
        gap: 8px;
        color: rgb(247, 249, 249);
        font-size: 15px;
        font-weight: 700;
    }

    .likeme-toast-close {
        width: 34px;
        height: 34px;
        border: none;
        background: transparent;
        color: rgb(113, 118, 123);
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        padding: 0;
        transition: all 0.2s ease;
        margin: -8px;
    }

    .likeme-toast-close:hover {
        color: rgb(247, 249, 249);
        background: rgba(239, 243, 244, 0.1);
    }

    .likeme-toast-actions {
        display: flex;
        gap: 12px;
    }

    .likeme-toast-button {
        flex: 1;
        border: none;
        border-radius: 9999px;
        cursor: pointer;
        padding: 0;
        transition: background-color 0.2s ease;
        overflow: hidden;
        background: none;
    }

    .likeme-button-content {
        display: flex;
        align-items: center;
        padding: 15px 24px;
        gap: 12px;
        width: 100%;
        height: 100%;
        transition: background-color 0.2s ease;
    }

    .likeme-lock-button .likeme-button-content {
        background: rgb(32, 35, 39);
        color: rgb(247, 249, 249);
    }

    .likeme-lock-button:hover .likeme-button-content {
        background: rgb(39, 44, 48);
    }

    .likeme-tip-button .likeme-button-content {
        background: rgb(255, 77, 124);
        color: white;
    }

    .likeme-tip-button:hover .likeme-button-content {
        background: rgb(255, 31, 90);
    }

    .likeme-button-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        font-weight: 700;
        min-width: 18px;
    }

    .likeme-button-label {
        font-size: 15px;
        font-weight: 700;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        flex: 1;
    }

    .likeme-button-amount {
        padding-left: 12px;
        margin-left: 12px;
        border-left: 1px solid rgba(255, 255, 255, 0.2);
        font-size: 15px;
        font-weight: 400;
    }

    @media (max-width: 640px) {
        .likeme-toast {
            bottom: 16px;
            width: calc(100% - 32px);
            padding: 16px;
        }

        .likeme-toast-actions {
            flex-direction: column;
            gap: 8px;
        }
        
        .likeme-button-content {
            justify-content: flex-start;
        }

        .likeme-button-amount {
            margin-left: auto;
        }
    }

    .likeme-message-input-wrapper {
        position: relative;
        width: 100%;
        box-sizing: border-box;
    }

    .likeme-clear-button {
        position: absolute;
        top: 8px;
        right: 8px;
        width: 24px;
        height: 24px;
        border: none;
        background: rgba(255, 77, 124, 0.1);
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0;
        transition: all 0.2s ease;
        opacity: 0.8;
        z-index: 2;
    }

    .likeme-clear-button:hover {
        background: rgba(255, 77, 124, 0.2);
        opacity: 1;
    }

    .likeme-clear-button svg {
        fill: rgb(255, 77, 124);
    }

    .likeme-message-field {
        margin-top: 12px;
        background: rgb(0, 0, 0);
        border-radius: 8px;
        padding: 8px;  /* Increased padding */
        border: 1px solid rgb(47, 51, 54);
        position: relative;
        width: 100%;
        box-sizing: border-box;
    }

    .likeme-clear-button {
        position: absolute;
        top: 50%;
        right: 8px;
        transform: translateY(-50%);
        width: 24px;
        height: 24px;
        border: none;
        background: rgba(255, 77, 124, 0.1);
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0;
        transition: all 0.2s ease;
        opacity: 0.8;
        z-index: 2;
    }

    .likeme-payment-methods {
        position: absolute;
        top: 32px;
        right: 32px;
        display: flex;
        gap: 8px;
        align-items: center;
    }

    .likeme-payment-method {
        width: 32px;
        height: 32px;
        border-radius: 8px;
        border: 2px solid transparent;
        cursor: pointer;
        padding: 6px;
        background: rgb(32, 35, 39);
        transition: all 0.2s ease;
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .likeme-payment-method:hover {
        background: rgb(39, 44, 48);
        transform: translateY(-2px);
    }

    .likeme-payment-method.active {
        border-color: rgb(255, 77, 124);
        background: rgba(255, 77, 124, 0.1);
    }

    .likeme-payment-method img {
        width: 100%;
        height: 100%;
        object-fit: contain;
        filter: brightness(0.9);
        transition: all 0.2s ease;
    }

    .likeme-payment-method:hover img {
        filter: brightness(1);
    }

    .likeme-payment-selected {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 48px;
        height: 48px;
        padding: 10px;
        background: rgb(32, 35, 39);
        border-radius: 12px;
        cursor: pointer;
        transition: all 0.2s ease;
        border: 1px solid rgb(47, 51, 54);
    }

    .likeme-payment-selected:hover {
        background: rgb(39, 44, 48);
        transform: scale(1.05);
    }

    .likeme-payment-selected img {
        width: 100%;
        height: 100%;
        object-fit: contain;
        filter: brightness(0.9);
        transition: all 0.2s ease;
    }

    .likeme-payment-selected:hover img {
        filter: brightness(1);
    }

    .likeme-payment-option {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 48px;
        height: 48px;
        padding: 10px;
        cursor: pointer;
        border-radius: 12px;
        transition: all 0.2s ease;
        background: rgb(39, 44, 48);
    }

    .likeme-payment-option:hover {
        transform: scale(1.05);
        background: rgb(47, 51, 54);
    }

    .likeme-payment-option.active {
        background: rgba(255, 77, 124, 0.1);
    }

    .likeme-payment-option img {
        width: 100%;
        height: 100%;
        object-fit: contain;
        filter: brightness(0.9);
        transition: all 0.2s ease;
    }

    .likeme-payment-option:hover img {
        filter: brightness(1);
    }

    .likeme-payment-method-tooltip {
        position: absolute;
        bottom: calc(100% + 8px);
        left: 50%;
        transform: translateX(-50%);
        background: rgb(32, 35, 39);
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        white-space: nowrap;
        color: rgb(247, 249, 249);
        opacity: 0;
        visibility: hidden;
        transition: all 0.2s ease;
        pointer-events: none;
    }

    .likeme-payment-method:hover .likeme-payment-method-tooltip {
        opacity: 1;
        visibility: visible;
    }

    .likeme-payment-method-tooltip::after {
        content: '';
        position: absolute;
        top: 100%;
        left: 50%;
        transform: translateX(-50%);
        border-width: 4px;
        border-style: solid;
        border-color: rgb(32, 35, 39) transparent transparent transparent;
    }

    .likeme-payment-selector {
        position: absolute;
        top: 16px;
        right: 16px;
        z-index: 1;
    }

    .likeme-payment-dropdown {
        position: relative;
    }

    .likeme-payment-selected {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 48px;
        height: 48px;
        padding: 8px;
        background: rgb(32, 35, 39);
        border-radius: 12px;
        cursor: pointer;
        transition: all 0.2s ease;
        border: 1px solid rgb(47, 51, 54);
    }

    .likeme-payment-selected:hover {
        background: rgb(39, 44, 48);
        transform: scale(1.05);
    }

    .likeme-payment-selected img {
        width: 32px;
        height: 32px;
        object-fit: contain;
        transition: transform 0.2s ease;
    }

    .likeme-payment-selected.active img {
        transform: scale(0.9);
    }

    .likeme-payment-options {
        position: absolute;
        top: calc(100% + 8px);
        right: 0;
        background: rgb(32, 35, 39);
        border-radius: 12px;
        border: 1px solid rgb(47, 51, 54);
        padding: 8px;
        display: none;
        grid-template-columns: repeat(2, 1fr);
        gap: 8px;
        width: max-content;
    }

    .likeme-payment-options.show {
        display: grid;
    }

    .likeme-payment-option {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 48px;
        height: 48px;
        padding: 8px;
        cursor: pointer;
        border-radius: 12px;
        transition: all 0.2s ease;
        background: rgb(39, 44, 48);
    }

    .likeme-payment-option:hover {
        transform: scale(1.05);
        background: rgb(47, 51, 54);
    }

    .likeme-payment-option.active {
        background: rgba(255, 77, 124, 0.1);
    }

    .likeme-payment-option img {
        width: 32px;
        height: 32px;
        object-fit: contain;
    }

    /* Add tooltip styles */
    .likeme-payment-option, .likeme-payment-selected {
        position: relative;
    }

    .likeme-payment-option::after, .likeme-payment-selected::after {
        content: attr(data-tooltip);
        position: absolute;
        bottom: -30px;
        left: 50%;
        transform: translateX(-50%);
        background: rgba(32, 35, 39, 0.9);
        color: rgb(247, 249, 249);
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        white-space: nowrap;
        opacity: 0;
        visibility: hidden;
        transition: all 0.2s ease;
        pointer-events: none;
    }

    .likeme-payment-option:hover::after, .likeme-payment-selected:hover::after {
        opacity: 1;
        visibility: visible;
        bottom: -25px;
    }

    .likeme-amount-item.custom {
        color: rgb(255, 77, 124) !important;
        font-size: 48px !important;
        font-weight: 700 !important;
        text-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .likeme-conversion-display {
        margin: 8px 0;
        font-size: 14px;
        color: rgb(113, 118, 123);
        transition: opacity 0.2s ease;
        text-align: center;
        min-height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .likeme-custom-amount {
        margin: 20px 0;
        position: relative;
    }

    .likeme-custom-amount-input {
        margin-bottom: 0;
    }
`;
document.head.appendChild(style); 

function initializePaymentMethods() {
    ['lock', 'tip'].forEach(type => {
        const modal = document.getElementById(`${type}Modal`);
        const paymentSelector = modal.querySelector('.likeme-payment-selector');

        // Restore last selected payment method from storage
        chrome.storage.local.get([`likemeSelectedPayment_${type}`], (result) => {
            const lastMethod = result[`likemeSelectedPayment_${type}`] || 'doge';
            modal.setAttribute('data-selected-payment', lastMethod);
            // Set UI to match last method
            paymentSelector.querySelectorAll('.likeme-payment-option').forEach(opt => {
                if (opt.getAttribute('data-method') === lastMethod) {
                    opt.classList.add('active');
                } else {
                    opt.classList.remove('active');
                }
            });
            const selected = paymentSelector.querySelector('.likeme-payment-selected');
            const option = paymentSelector.querySelector(`.likeme-payment-option[data-method="${lastMethod}"]`);
            if (option) {
                selected.innerHTML = `<img src="${option.querySelector('img').src}" alt="${option.getAttribute('data-tooltip')}">`;
                selected.setAttribute('data-tooltip', option.getAttribute('data-tooltip'));
            }
            // Update payment method and conversion rate
            updateSelectedPaymentMethod(lastMethod, modal);
        });

        // Add click handler for payment options
        paymentSelector.addEventListener('click', (e) => {
            const option = e.target.closest('.likeme-payment-option');
            if (option) {
                const method = option.getAttribute('data-method');
                const dropdown = paymentSelector.querySelector('.likeme-payment-options');
                const selected = paymentSelector.querySelector('.likeme-payment-selected');

                // Update selected payment method UI
                paymentSelector.querySelectorAll('.likeme-payment-option').forEach(opt => {
                    opt.classList.remove('active');
                });
                option.classList.add('active');

                // Update selected icon
                selected.innerHTML = `<img src="${option.querySelector('img').src}" alt="${option.getAttribute('data-tooltip')}">`;
                selected.setAttribute('data-tooltip', option.getAttribute('data-tooltip'));

                // Hide dropdown
                dropdown.classList.remove('show');
                selected.classList.remove('active');

                // Persist the user's choice
                chrome.storage.local.set({[`likemeSelectedPayment_${type}`]: method});

                // Update payment method and conversion rate
                updateSelectedPaymentMethod(method, modal);
            } else if (e.target.closest('.likeme-payment-selected')) {
                const dropdown = paymentSelector.querySelector('.likeme-payment-options');
                const selected = paymentSelector.querySelector('.likeme-payment-selected');
                dropdown.classList.toggle('show');
                selected.classList.toggle('active');
            }
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.likeme-payment-selector')) {
                const dropdown = paymentSelector.querySelector('.likeme-payment-options');
                const selected = paymentSelector.querySelector('.likeme-payment-selected');
                dropdown.classList.remove('show');
                selected.classList.remove('active');
            }
        });
    });
}

function updateSelectedPaymentMethod(method, modal) {
    // Store the selected method
    modal.setAttribute('data-selected-payment', method);
    
    // Get the current amount (either custom or from carousel)
    const customInput = modal.querySelector('.likeme-custom-amount-input');
    const customAmount = customInput.value;
    const type = modal.id.replace('Modal', '');
    
    // If there's a custom amount, keep it displayed and update conversion
    if (customAmount && !isNaN(customAmount)) {
        const numericValue = parseFloat(customAmount);
        const formattedAmount = numericValue < 1 ? 
            `$${numericValue.toFixed(2)}` : 
            `$${numericValue.toLocaleString()}`;

        // Update the carousel display
        const carouselContainer = modal.querySelector('.likeme-amount-carousel');
        let customAmountItem = carouselContainer.querySelector('.likeme-amount-item.custom');
        if (!customAmountItem) {
            customAmountItem = document.createElement('div');
            customAmountItem.className = 'likeme-amount-item custom active';
            carouselContainer.appendChild(customAmountItem);
        }
        
        // Update custom amount item
        customAmountItem.setAttribute('data-value', numericValue);
        customAmountItem.setAttribute('data-base-amount', numericValue);
        customAmountItem.textContent = formattedAmount;

        // Hide other amount items
        carouselContainer.querySelectorAll('.likeme-amount-item:not(.custom)').forEach(item => {
            item.style.display = 'none';
        });
        
        // Show and position custom amount item
        customAmountItem.style.display = 'flex';
        customAmountItem.style.opacity = '1';
        customAmountItem.style.transform = 'translateY(0) scale(1)';

        // Update modal title
        const modalTitle = modal.querySelector('.likeme-modal-title');
        modalTitle.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                ${type === 'lock' ? 
                    '<rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path>' : 
                    '<path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>'}
            </svg>
            ${type === 'tip' ? 
                `Tip @${carouselState.tip.username}: ${formattedAmount}` : 
                `Lock Amount: ${formattedAmount}`}
        `;

        // Update conversion display
        updateCustomAmountConversion(customAmount, method, modal);
    } else {
        // If no custom amount, get the current carousel amount
        const currentIndex = carouselState[type].currentIndex;
        const currentItem = carouselState[type].items[currentIndex];
        const currentAmount = currentItem.getAttribute('data-base-amount');
        
        // Update conversion display for carousel amount
        updateCustomAmountConversion(currentAmount, method, modal);
        
        // Update amounts display
        updateAmountsForPaymentMethod(method, modal);
        updateModalTitle(method, modal);
    }
}

function updateAmountsForPaymentMethod(method, modal) {
    // Define conversion rates (you can update these or fetch from an API)
    const conversionRates = {
        doge: { rate: 1, decimals: 2 },
        bells: { rate: 100, decimals: 0 },
        bsv: { rate: 0.00001, decimals: 8 },
        bch: { rate: 0.00001, decimals: 8 },
        btc: { rate: 0.000001, decimals: 8 },
        ltc: { rate: 0.0001, decimals: 8 }
    };

    const { rate, decimals } = conversionRates[method] || { rate: 1, decimals: 2 };
    
    // Update custom amount input placeholder
    const customInput = modal.querySelector('.likeme-custom-amount-input');
    if (customInput) {
        customInput.setAttribute('placeholder', `Enter amount in USD`);
    }
}

function updateModalTitle(method, modal) {
    const title = modal.querySelector('.likeme-modal-title');
    const modalType = modal.id === 'lockModal' ? 'Lock' : 'Tip';
    const currentAmount = modal.querySelector('.likeme-amount-item.active')?.getAttribute('data-base-amount') || '0';
    const formattedAmount = parseFloat(currentAmount) < 1 ? 
        `$${parseFloat(currentAmount).toFixed(2)}` : 
        `$${parseFloat(currentAmount).toLocaleString()}`;
    if (modalType === 'Tip') {
        const avatar = carouselState.tip.avatar ? `<img src="${carouselState.tip.avatar}" alt="avatar" class="likeme-tip-avatar">` : '';
        title.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                <path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
            </svg>
            Tip/Pay ${avatar}@${carouselState.tip.username}: ${formattedAmount}
        `;
    } else {
        title.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
            </svg>
            Lock Amount: ${formattedAmount}
        `;
    }
}

function getPaymentMethodSymbol(method) {
    const symbols = {
        doge: 'Ð',
        bells: '🔔',
        bsv: '₿',
        bch: '₿',
        btc: '₿',
        ltc: 'Ł'
    };
    return symbols[method] || '$';
}

// Helper functions for conversion rates and decimals
function getConversionRate(method) {
    const rates = {
        doge: 1,
        bells: 100,
        bsv: 0.00001,
        bch: 0.00001,
        btc: 0.000001,
        ltc: 0.0001
    };
    return rates[method] || 1;
}

function getDecimals(method) {
    const decimals = {
        doge: 2,
        bells: 0,
        bsv: 8,
        bch: 8,
        btc: 8,
        ltc: 8
    };
    return decimals[method] || 2;
}

function updateCustomAmountConversion(value, method, modal) {
    const conversionDisplay = modal.querySelector('.likeme-conversion-display');
    if (!conversionDisplay) return;

    if (value && !isNaN(value) && value > 0) {
        const numericValue = parseFloat(value);
        const { rate, symbol, name } = getPaymentMethodInfo(method);
        const convertedAmount = (numericValue * rate).toFixed(getDecimals(method));
        
        // Create or update conversion input and wrapper
        let wrapper = conversionDisplay.querySelector('.likeme-conversion-wrapper');
        let conversionInput = conversionDisplay.querySelector('.likeme-conversion-input');
        
        if (!wrapper || !conversionInput) {
            // Create new elements if they don't exist
            conversionInput = document.createElement('input');
            conversionInput.className = 'likeme-conversion-input';
            conversionInput.type = 'number';
            conversionInput.step = 'any';
            
            // Add input handler for conversion amount
            conversionInput.oninput = (e) => {
                const cryptoValue = parseFloat(e.target.value);
                if (cryptoValue && !isNaN(cryptoValue) && cryptoValue > 0) {
                    // Get current payment method info
                    const currentMethod = modal.getAttribute('data-selected-payment');
                    const { rate } = getPaymentMethodInfo(currentMethod);
                    // Calculate USD value based on crypto amount and rate
                    // For crypto to USD, multiply by (1/rate) since rate is USD-to-crypto
                    const usdValue = (cryptoValue * (1/rate)).toFixed(2);
                    const customInput = modal.querySelector('.likeme-custom-amount-input');
                    // Update USD input without triggering its input event
                    customInput.value = usdValue;
                    // Update modal title and other displays
                    const type = modal.id.replace('Modal', '');
                    const formattedUsdAmount = `$${parseFloat(usdValue).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
                    // Update modal title
                    const modalTitle = modal.querySelector('.likeme-modal-title');
                    if (type === 'tip') {
                        const avatar = carouselState.tip.avatar ? `<img src="${carouselState.tip.avatar}" alt="avatar" class="likeme-tip-avatar">` : '';
                        modalTitle.innerHTML = `
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                            </svg>
                            Tip/Pay ${avatar}@${carouselState.tip.username}: ${formattedUsdAmount}
                        `;
                        // Update post comment textarea with new USD amount
                        const messageText = modal.querySelector('.likeme-message-input');
                        if (messageText) {
                            messageText.value = `Just sent you ${formattedUsdAmount} with @LikeMe`;
                        }
                    } else {
                        modalTitle.innerHTML = `
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                            </svg>
                            Lock Amount: ${formattedUsdAmount}
                        `;
                    }
                    // --- Update carousel custom amount item ---
                    const carouselContainer = modal.querySelector('.likeme-amount-carousel');
                    let customAmountItem = carouselContainer.querySelector('.likeme-amount-item.custom');
                    if (!customAmountItem) {
                        customAmountItem = document.createElement('div');
                        customAmountItem.className = 'likeme-amount-item custom active';
                        carouselContainer.appendChild(customAmountItem);
                    }
                    // Update custom amount item
                    customAmountItem.setAttribute('data-value', usdValue);
                    customAmountItem.setAttribute('data-base-amount', usdValue);
                    customAmountItem.textContent = formattedUsdAmount;
                    // Hide other amount items
                    carouselContainer.querySelectorAll('.likeme-amount-item:not(.custom)').forEach(item => {
                        item.style.display = 'none';
                    });
                    // Show and position custom amount item
                    customAmountItem.style.display = 'flex';
                    customAmountItem.style.opacity = '1';
                    customAmountItem.style.transform = 'translateY(0) scale(1)';
                }
            };
            
            wrapper = document.createElement('div');
            wrapper.className = 'likeme-conversion-wrapper';
            
            conversionDisplay.innerHTML = '';
            conversionDisplay.appendChild(wrapper);
        }
        
        // Always update the wrapper content to reflect current payment method
        wrapper.innerHTML = `≈ ${symbol}`;
        wrapper.appendChild(conversionInput);
        wrapper.appendChild(document.createTextNode(` ${name}`));
        
        // Update conversion input value without triggering input event
        conversionInput.value = convertedAmount;
        conversionDisplay.style.opacity = '1';
    } else {
        conversionDisplay.innerHTML = '';
        conversionDisplay.style.opacity = '0';
    }
}

// Add styles for the conversion input
document.head.appendChild(document.createElement('style')).textContent = `
    .likeme-conversion-wrapper {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        color: rgb(113, 118, 123);
        font-size: 14px;
    }

    .likeme-conversion-input {
        width: 120px;
        background: transparent;
        border: none;
        border-bottom: 1px solid rgb(47, 51, 54);
        color: rgb(113, 118, 123);
        font-size: 14px;
        padding: 2px 4px;
        text-align: center;
        transition: all 0.2s ease;
    }

    .likeme-conversion-input:focus {
        outline: none;
        border-bottom-color: rgb(255, 77, 124);
        color: rgb(247, 249, 249);
    }

    .likeme-conversion-input::-webkit-inner-spin-button,
    .likeme-conversion-input::-webkit-outer-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    .likeme-conversion-input {
        -moz-appearance: textfield;
    }
`;

function getPaymentMethodInfo(method) {
    const info = {
        doge: { rate: 15.5, symbol: 'Ð', name: 'DOGE' },         // 1 USD = 15.5 DOGE
        bells: { rate: 100, symbol: '🔔', name: 'Bells' },       // 1 USD = 100 Bells
        bsv: { rate: 0.000037, symbol: '₿', name: 'BSV' },      // 1 USD = 0.000037 BSV
        bch: { rate: 0.0033, symbol: '₿', name: 'BCH' },        // 1 USD = 0.0033 BCH
        btc: { rate: 0.000023, symbol: '₿', name: 'BTC' },      // 1 USD = 0.000023 BTC
        ltc: { rate: 0.011, symbol: 'Ł', name: 'LTC' }          // 1 USD = 0.011 LTC
    };
    return info[method] || { rate: 1, symbol: '$', name: 'USD' };
}

// Add after getPostUsername
function getPostAvatar(post) {
    if (!post) return null;
    // Try to find avatar image within the post
    const avatarImg = post.querySelector('img[src*="profile_images"], img[alt*="Avatar"], img[alt*="Image"]');
    if (avatarImg) {
        return avatarImg.src;
    }
    return null;
}

// Add this new function after createToggleButton or at the end of the file
function setupPostEventListeners() {
    const platform = getCurrentPlatform();
    if (!platformConfig || !platformConfig[platform]) return;
    const config = platformConfig[platform];
    if (!config?.enabled) return;
    
    // Helper to add listeners to a post
    function addListeners(post) {
        if (post._likemeListeners) return; // Prevent double-listening
        post._likemeListeners = true;
        
        // Only handle touch events here since mouse events are handled by updateHeartPosition
        post.addEventListener('touchstart', (e) => {
            if (!isEnabled || !heart || heartState.isLocked) return;
            const rect = post.getBoundingClientRect();
            const touch = e.touches[0];
            updateHeartPosition(touch.clientX, touch.clientY);
        }, {passive: true});
        
        post.addEventListener('touchmove', (e) => {
            if (!isEnabled || !heart || heartState.isLocked) return;
            const touch = e.touches[0];
            updateHeartPosition(touch.clientX, touch.clientY);
        }, {passive: true});
        
        post.addEventListener('touchend', (e) => {
            if (heartState.isLocked) return;
            setTimeout(() => {
                heart.classList.remove('active');
                heartState.currentTarget = null;
            }, 200);
        }, {passive: true});
    }
    
    // Add listeners to all current posts
    const posts = document.querySelectorAll(config.selectors.post);
    posts.forEach(addListeners);
    
    // Observe for new posts
    const timeline = document.querySelector('div[data-testid="primaryColumn"]') || document.body;
    const observer = new MutationObserver(() => {
        const newPosts = document.querySelectorAll(config.selectors.post);
        newPosts.forEach(addListeners);
    });
    observer.observe(timeline, { childList: true, subtree: true });
}

window.addEventListener('scroll', () => {
    if (!isEnabled || !heart || heartState.isLocked) return;
    // On scroll, reposition heart based on last known mouse position
    updateHeartPosition(lastMousePosition.x, lastMousePosition.y);
}, {passive: true});

// Add this utility function near the top or with other helpers
function formatCryptoAmount(amount, decimals = 8) {
    let n = Number(amount);
    if (!isFinite(n) || n === 0) return '0';
    // Remove trailing zeros after decimal
    return n.toLocaleString(undefined, {
        minimumFractionDigits: 2,
        maximumFractionDigits: decimals,
        useGrouping: false
    }).replace(/\.0+$/, '');
}

// ... inside showActionChoiceToast ...
function formatCryptoAmountDisplay(amountStr) {
    // Extract symbol, number, and currency
    const match = amountStr.match(/^([^\d\s]+)?([\d\.eE\-]+)\s*([A-Za-z]*)$/);
    if (!match) return amountStr;
    const symbol = match[1] || '';
    const num = match[2] || '0';
    const currency = match[3] || '';
    return `${symbol}${formatCryptoAmount(num)}${currency ? ' ' + currency : ''}`;
}
// ...

// === BEGIN: Live CoinGecko Rates Integration ===

// CoinGecko IDs for supported coins
const COINGECKO_IDS = {
    doge: 'dogecoin',
    bells: 'bellscoin',
    bsv: 'bitcoin-cash-sv', // corrected from 'bitcoin-sv'
    bch: 'bitcoin-cash',
    btc: 'bitcoin',
    ltc: 'litecoin'
};

// Default fallback rates (1 USD = X coins)
const DEFAULT_RATES = {
    doge: { rate: 15.5, symbol: 'Ð', name: 'DOGE', decimals: 2 },
    bells: { rate: 100, symbol: '🔔', name: 'Bells', decimals: 0 },
    bsv: { rate: 0.000037, symbol: '₿', name: 'BSV', decimals: 8 },
    bch: { rate: 0.0033, symbol: '₿', name: 'BCH', decimals: 8 },
    btc: { rate: 0.000023, symbol: '₿', name: 'BTC', decimals: 8 },
    ltc: { rate: 0.011, symbol: 'Ł', name: 'LTC', decimals: 8 }
};

// Store live rates here
let liveRates = { ...DEFAULT_RATES };
let lastRatesUpdate = 0;
let liveRatesAvailable = false;

async function fetchLiveRates() {
    try {
        const ids = Object.values(COINGECKO_IDS).join(',');
        const url = `https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd`;
        const resp = await fetch(url);
        if (!resp.ok) throw new Error('Failed to fetch rates');
        const data = await resp.json();
        // Calculate 1 USD = X coins for each
        Object.entries(COINGECKO_IDS).forEach(([key, id]) => {
            if (data[id] && data[id].usd > 0) {
                liveRates[key] = {
                    ...DEFAULT_RATES[key],
                    rate: 1 / data[id].usd
                };
            }
        });
        lastRatesUpdate = Date.now();
        liveRatesAvailable = true;
        // Optionally, update UI to show 'Live' indicator
    } catch (e) {
        liveRates = { ...DEFAULT_RATES };
        liveRatesAvailable = false;
    }
}

// Fetch on load and every 60 seconds
fetchLiveRates();
setInterval(fetchLiveRates, 60000);

// === END: Live CoinGecko Rates Integration ===

// ... existing code ...

// Replace getPaymentMethodInfo to use liveRates
function getPaymentMethodInfo(method) {
    return liveRates[method] || { rate: 1, symbol: '$', name: 'USD', decimals: 2 };
}

// Replace getConversionRate and getDecimals to use liveRates
function getConversionRate(method) {
    return (liveRates[method] && liveRates[method].rate) || 1;
}

function getDecimals(method) {
    return (liveRates[method] && liveRates[method].decimals) || 2;
}

// Optionally, you can add a small UI indicator for live/fallback rates
// Example: add a span with id 'likeme-rates-indicator' to the modal title and update its text
// ... existing code ...

// Add style to ensure toast links are clickable
const toastLinkStyle = document.createElement('style');
toastLinkStyle.textContent = `
.likeme-toast-message a {
  pointer-events: auto !important;
}
`;
document.head.appendChild(toastLinkStyle);

// ... existing code ...
// Add style for vertical stacking in toast message
const toastMessageStyle = document.createElement('style');
toastMessageStyle.textContent = `
.likeme-toast-message {
  display: flex !important;
  flex-direction: column !important;
  align-items: flex-start !important;
  gap: 0 !important;
}
`;
document.head.appendChild(toastMessageStyle);
// ... existing code ...

// ... existing code ...
// Add compact modal and scrollable content styles
const compactModalStyle = document.createElement('style');
compactModalStyle.textContent = `
.likeme-modal-content {
  max-height: 80vh !important;
  overflow-y: auto !important;
  padding-top: 20px !important;
  padding-bottom: 20px !important;
}
.likeme-post-snippet {
  margin-bottom: 8px !important;
  max-height: 75px !important;
  overflow-y: auto !important;
}
.likeme-amount-carousel {
  margin: 10px 0 !important;
  height: 120px !important;
}
.likeme-custom-amount {
  margin: 10px 0 !important;
}
.likeme-message-section {
  margin-top: 12px !important;
  padding-top: 12px !important;
}
.likeme-modal-actions {
  margin-top: 12px !important;
  gap: 8px !important;
}
.likeme-brand {
  margin-top: 16px !important;
  padding-top: 12px !important;
}
`;
document.head.appendChild(compactModalStyle);
// ... existing code ...

function createTutorialModal() {
    const tutorialModal = document.createElement('div');
    tutorialModal.className = 'likeme-modal';
    tutorialModal.id = 'tutorialModal';
    tutorialModal.setAttribute('role', 'dialog');
    tutorialModal.setAttribute('aria-label', 'LikeMe Tutorial');
    tutorialModal.innerHTML = `
        <div class="likeme-modal-content">
            <div class="likeme-modal-title">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                </svg>
                Welcome to LikeMe!
            </div>
            <div class="likeme-tutorial-content" style="margin: 20px 0; line-height: 1.6; color: rgb(247, 249, 249);">
                <p style="margin-bottom: 16px;">Here's how to use LikeMe:</p>
                <ol style="margin: 0; padding-left: 20px;">
                    <li style="margin-bottom: 12px;">Click the heart icon to share</li>
                    <li style="margin-bottom: 12px;">Choose to either Lock or Tip/Pay</li>
                    <li style="margin-bottom: 12px;">Select your preferred payment method</li>
                    <li style="margin-bottom: 12px;">Enter the amount you want to send</li>
                    <li style="margin-bottom: 12px;">Optionally add a comment/reply</li>
                </ol>
                <p style="margin-top: 20px; font-size: 14px; color: rgb(113, 118, 123);">
                    Note: LikeMe is not affiliated with, endorsed by, or associated with X (formerly Twitter), YouTube, GitHub, Facebook, or Google.
                </p>
            </div>
            <div class="likeme-tutorial-confirm" style="margin-top: 24px; padding-top: 16px; border-top: 1px solid rgb(47, 51, 54);">
                <label class="likeme-message-checkbox" style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                    <input type="checkbox" id="tutorialConfirm" style="width: 18px; height: 18px;">
                    <span style="color: rgb(247, 249, 249);">I understand how to use LikeMe</span>
                </label>
            </div>
            <div class="likeme-modal-actions" style="margin-top: 24px;">
                <button class="likeme-modal-button confirm" id="tutorialStart" disabled style="opacity: 0.5; cursor: not-allowed;">Get Started</button>
            </div>
        </div>
    `;

    document.body.appendChild(tutorialModal);

    // Add event listeners
    const confirmCheckbox = tutorialModal.querySelector('#tutorialConfirm');
    const startButton = tutorialModal.querySelector('#tutorialStart');

    confirmCheckbox.addEventListener('change', () => {
        startButton.disabled = !confirmCheckbox.checked;
        startButton.style.opacity = confirmCheckbox.checked ? '1' : '0.5';
        startButton.style.cursor = confirmCheckbox.checked ? 'pointer' : 'not-allowed';
    });

    startButton.addEventListener('click', () => {
        if (confirmCheckbox.checked) {
            chrome.storage.local.set({ 'likemeTutorialShown': true }, () => {
                tutorialModal.remove();
            });
        }
    });

    // Show the modal
    tutorialModal.classList.add('show-modal');
}